// ═══════════════════════════════════════════════════════════
//  OBS WEBSOCKET CLIENT
//  OBS Studio'ya baglanarak kayit ve scene kontrolü saglar
// ═══════════════════════════════════════════════════════════

class OBSClient {
    constructor() {
        this.ws = null;
        this.connected = false;
        this.authenticated = false;
        this.messageId = 1;
        this.callbacks = {};
        this.config = null;
    }
    
    // OBS WebSocket'e baglan
    async connect(config) {
        this.config = config;
        
        return new Promise((resolve, reject) => {
            if (this.connected) {
                resolve(true);
                return;
            }
            
            const wsUrl = `ws://${config.OBS_HOST}:${config.OBS_PORT}`;
            
            try {
                this.ws = new WebSocket(wsUrl);
            } catch (e) {
                console.error('OBS: WebSocket baglanti hatasi:', e);
                reject(e);
                return;
            }
            
            this.ws.onopen = () => {
                console.log('OBS: Baglantı acildi');
                this.connected = true;
            };
            
            this.ws.onmessage = (event) => {
                this.handleMessage(event.data, resolve, reject);
            };
            
            this.ws.onerror = (error) => {
                console.error('OBS: WebSocket hatasi:', error);
                reject(error);
            };
            
            this.ws.onclose = () => {
                console.log('OBS: Baglanti kapandi');
                this.connected = false;
                this.authenticated = false;
            };
            
            // Timeout
            setTimeout(() => {
                if (!this.authenticated) {
                    reject(new Error('OBS: Kimlik dogrulama zaman asimi'));
                }
            }, 5000);
        });
    }
    
    // Kimlik dogrulama
    async authenticate() {
        if (!this.config || !this.config.OBS_PASSWORD) {
            throw new Error('OBS: Sifre ayarlanmamis');
        }
        
        const authResponse = await this.sendRequest('GetAuthRequired', {});
        
        if (authResponse.authRequired) {
            const authSend = await this.sendRequest('Authenticate', {
                password: this.config.OBS_PASSWORD
            });
            
            if (!authSend.ok) {
                throw new Error('OBS: Kimlik dogrulama basarisiz');
            }
        }
        
        this.authenticated = true;
        console.log('OBS: Kimlik dogrulandi');
        return true;
    }
    
    // Get Scene List
    async getSceneList() {
        return await this.sendRequest('GetSceneList');
    }
    
    // Get Current Scene
    async getCurrentScene() {
        const result = await this.sendRequest('GetCurrentProgramScene');
        return result.name;
    }
    
    // Set Current Scene
    async setScene(sceneName) {
        return await this.sendRequest('SetCurrentProgramScene', {
            'scene-name': sceneName
        });
    }
    
    // Get Stream Status
    async getStreamStatus() {
        return await this.sendRequest('GetStreamStatus');
    }
    
    // Start Streaming
    async startStreaming() {
        return await this.sendRequest('StartStream');
    }
    
    // Stop Streaming
    async stopStreaming() {
        return await this.sendRequest('StopStream');
    }
    
    // Get Recording Status
    async getRecordingStatus() {
        return await this.sendRequest('GetRecordingStatus');
    }
    
    // Start Recording
    async startRecording() {
        return await this.sendRequest('StartRecording');
    }
    
    // Stop Recording
    async stopRecording() {
        return await this.sendRequest('StopRecording');
    }
    
    // Get Sources List
    async getSourcesList() {
        return await this.sendRequest('GetSourcesList');
    }
    
    // Send message to OBS
    sendRequest(method, params = {}) {
        return new Promise((resolve, reject) => {
            if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
                reject(new Error('OBS: Bagli degil'));
                return;
            }
            
            const messageId = this.messageId++;
            const request = {
                'request-type': method,
                'message-id': messageId.toString(),
                ...params
            };
            
            this.callbacks[messageId] = { resolve, reject };
            this.ws.send(JSON.stringify(request));
        });
    }
    
    // Mesajlari isle
    handleMessage(data, connectResolve, connectReject) {
        try {
            const message = JSON.parse(data);
            
            if (message['message-id']) {
                const msgId = parseInt(message['message-id']);
                const callback = this.callbacks[msgId];
                
                if (callback) {
                    if (message.status === 'ok' || message.response) {
                        callback.resolve(message.response || message);
                    } else if (message.comment) {
                        callback.reject(new Error(message.comment));
                    } else {
                        callback.resolve(message);
                    }
                    delete this.callbacks[msgId];
                }
            }
            
            // Authentication response
            if (message.authRequired !== undefined) {
                if (this.config && this.config.OBS_PASSWORD && !this.authenticated) {
                    this.authenticate()
                        .then(() => connectResolve(true))
                        .catch(connectReject);
                } else {
                    this.authenticated = true;
                    connectResolve(true);
                }
            }
            
        } catch (e) {
            console.error('OBS: Mesaj isleme hatasi:', e);
        }
    }
    
    // Baglantiyi kapat
    disconnect() {
        if (this.ws) {
            this.ws.close();
            this.ws = null;
        }
        this.connected = false;
        this.authenticated = false;
    }
}

// ═══════════════════════════════════════════════════════════
//  OTOMATIK YARDIMCI FONKSIYONLAR
// ═══════════════════════════════════════════════════════════

let obsClient = null;

async function obsConnect(config) {
    if (!obsClient) {
        obsClient = new OBSClient();
    }
    
    if (!obsClient.connected) {
        await obsClient.connect(config);
        if (config.OBS_PASSWORD) {
            await obsClient.authenticate();
        }
    }
    
    return obsClient;
}

async function obsStartStream(config) {
    const client = await obsConnect(config);
    try {
        await client.startStreaming();
        logOBS('Canli yayin baslatildi');
    } catch (e) {
        console.log('OBS: Stream baslatma hatasi (normal olabilir):', e.message);
    }
}

async function obsStopStream(config) {
    const client = await obsConnect(config);
    try {
        await client.stopStreaming();
        logOBS('Canli yayin durduruldu');
    } catch (e) {
        console.log('OBS: Stream durdurma hatasi:', e.message);
    }
}

async function obsStartRecording(config) {
    const client = await obsConnect(config);
    try {
        await client.startRecording();
        logOBS('Kayit baslatildi');
    } catch (e) {
        console.log('OBS: Kayit baslatma hatasi:', e.message);
    }
}

async function obsStopRecording(config) {
    const client = await obsConnect(config);
    try {
        await client.stopRecording();
        logOBS('Kayit durduruldu');
    } catch (e) {
        console.log('OBS: Kayit durdurma hatasi:', e.message);
    }
}

async function obsChangeScene(config, sceneName) {
    const client = await obsConnect(config);
    try {
        await client.setScene(sceneName);
        logOBS(`Scene degisti: ${sceneName}`);
    } catch (e) {
        console.log('OBS: Scene degistirme hatasi:', e.message);
    }
}

function logOBS(message) {
    const time = new Date().toLocaleTimeString('tr-TR');
    console.log(`[OBS ${time}] ${message}`);
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        OBSClient,
        obsConnect,
        obsStartStream,
        obsStopStream,
        obsStartRecording,
        obsStopRecording,
        obsChangeScene
    };
}