// ═══════════════════════════════════════════════════════
//  LOCALIZATION (i18n)
// ═══════════════════════════════════════════════════════
let currentLang = 'tr';

const langConfig = {
    tr: {
        
        fighter1: "🔴 SAVAŞÇI 1",
        fighter2: "🔵 SAVAŞÇI 2",
        arenaTitle: "🏟️ ARENA",
        wizard: "🧙 Büyücü",
        paladin: "🛡️ Paladin",
        assassin: "🗡️ Suikastçi",
        berserker: "🪓 Berserker",
        monk: "👊 Monk",
        teamLogo: "⚽ Takım Logosu:",
        face: "📷 Yüz",
        name: "İsim:",
        speed: "Hız:",
        attackDmg: "Saldırı DMG:",
        armor: "Zırh:",
        size: "Boyut:",
        color: "Renk:",
        ability: "Yetenek:",
        abilityDmg: "Yetenek DMG:",
        abilityCd: "Yetenek CD(s):",
        ground: "Zemin:",
        gravity: "Yerçekimi:",
        friction: "Sürtünme:",
        obstacles: "Engeller:",
        aiIntelligence: "AI Zekası:",
        commentary: "Yorum:",
        powerup: "Güçlenme:",
        introAnim: "Giriş Anim.:",
        sound: "Ses:",
        volume: "Ses Seviyesi:",
        effects: "🎬 Efektler:",
        soundTitle: "🔊 Ses:",
        optStone: "🪨 Taş Arena",
        optLava: "🌋 Lav",
        optIce: "❄️ Buz",
        optForest: "🌳 Orman",
        optVoid: "🌌 Boşluk",
        optColosseum: "🏛️ Kolezyum",
        optMoon: "🌕 Ay Yüzeyi",
        optSwamp: "🦠 Zehirli Bataklık",
        optCyberpunk: "🦾 Siberpunk",
        optNone: "Yok",
        optFew: "Az (2)",
        optNormal: "Normal (4)",
        optMany: "Çok (8)",
        optLow: "Düşük",
        optMid: "Normal",
        optHigh: "Yüksek",
        optOn: "Açık",
        optOff: "Kapalı",
        fightBtn: "⚔️ SAVAŞ!",
        pauseBtn: "⏸️ DURDUR",
        resumeBtn: "▶️ DEVAM",
        resetBtn: "🔄 SIFIRLA",
        randomBtn: "🎲 RASTGELE",
        recLandBtn: "🎬 YATAY KAYIT",
        recPortBtn: "📱 DİKEY KAYIT",
        stopRecBtn: "⏹️ KAYDI DURDUR",
        replayBtn: "TEKRAR OYNA",
        pauseBtn: "⏸️ DURDUR",
        resumeBtn: "▶️ DEVAM",
        ready: "Hazır",
        start: "SAVAŞ BAŞLADI!",
        miracleHit: "MUCİZEVİ VURUŞ!",
        combo: "KOMBO!",
        lightning: "⚡ Elektrik Dalgası!",
        fireball: "🔥 Ateş Topu!",
        ice: "❄️ Buz Fırtınası!",
        hammer: "🔨 Kutsal Çekiç!",
        dash: "💨 Gölge Atılımı!",
        rage: "😤 Çılgın Öfke aktif!",
        summon: "💀 Ölü Çağırma!",
        shockwave: "🌊 Şok Dalgası!",
        poison: "🧪 Zehir Bulutu!",
        wins: "KAZANDI!",
        round: "Round",
        score: "Skor",
        dmg: "DMG",
        abilities: "Yetenek",
        winMsg: "Round {round}'i kazandı!",
        finalScore: "Final Skor",
        slowMo: "◉ YAVAŞ ÇEKİM",
        meteorMsg: "☄️ METEOR YAĞMURU BAŞLADI! (Ani Ölüm)",
        laserMsg: "⚡ DİKKAT LAZERLER AKTİF!",
        superchatPower: "için Süper Güç!",
        supportedTeam: "desteklendi!",
        system: "Sistem",
        connectedPort: "Port {port} üzerinden WebSocket'e bağlanıldı.",
        simUser: "İzleyici",
        simVip: "Destekçi",
        voteStart: "Oylama Başladı! Chat'e takım yazın...",
        voteTimer: "Son {time} saniye",
        autoMatchStart: "Sonraki Maç: {t1} vs {t2}",
        logDamage: "{source} → {target}: {dmg} hasar!",
        logPowerup: "{name} {type} güçlenmesi aldı!",
        logDying: "{name} can çekişiyor!",
        logComeback: "{name} geri dönebilir mi?!",
        logCombo3: "{name} 3'LÜ KOMBO!",
        logComboComplete: "{name} KOMBO tamamladı!",
        logRecStart: "🎬 {mode} kayıt başladı!",
        logRecStop: "⏹️ Kayıt durduruluyor...",
        logWin: "🏆 {name} Round {round}'i kazandı! (Skor: {s0}-{s1})",
        logRoundStart: "--- Round {round} Başladı! ---",
        logSuperchat: "{name} SUPERCHAT!",
        minion: "'ın minyonu",
        optLightning: "⚡ Elektrik Dalgası",
        optFireball: "🔥 Ateş Topu",
        optIce: "❄️ Buz Fırtınası",
        optHammer: "🔨 Kutsal Çekiç",
        optDash: "💨 Gölge Atılımı",
        optRage: "😤 Çılgın Öfke",
        optSummon: "💀 Ölü Çağırma",
        optCombo: "👊 Kombo Vuruş",
        optShockwave: "🌊 Şok Dalgası",
        optPoison: "🧪 Zehir Bulutu"
    },
    en: {
        
        fighter1: "🔴 FIGHTER 1",
        fighter2: "🔵 FIGHTER 2",
        arenaTitle: "🏟️ ARENA",
        wizard: "🧙 Wizard",
        paladin: "🛡️ Paladin",
        assassin: "🗡️ Assassin",
        berserker: "🪓 Berserker",
        monk: "👊 Monk",
        teamLogo: "⚽ Team Logo:",
        face: "📷 Face",
        name: "Name:",
        speed: "Speed:",
        attackDmg: "Attack DMG:",
        armor: "Armor:",
        size: "Size:",
        color: "Color:",
        ability: "Ability:",
        abilityDmg: "Ability DMG:",
        abilityCd: "Ability CD(s):",
        ground: "Ground:",
        gravity: "Gravity:",
        friction: "Friction:",
        obstacles: "Obstacles:",
        aiIntelligence: "AI Level:",
        commentary: "Caster:",
        powerup: "Powerups:",
        introAnim: "Intro Anim:",
        sound: "Sound:",
        volume: "Volume:",
        effects: "🎬 Effects:",
        soundTitle: "🔊 Sound:",
        optStone: "🪨 Stone Arena",
        optLava: "🌋 Lava Pit",
        optIce: "❄️ Glacier",
        optForest: "🌳 Dark Forest",
        optVoid: "🌌 The Void",
        optColosseum: "🏛️ Colosseum",
        optMoon: "🌕 Moon Surface",
        optSwamp: "🦠 Toxic Swamp",
        optCyberpunk: "🦾 Cyberpunk",
        optNone: "None",
        optFew: "Few (2)",
        optNormal: "Normal (4)",
        optMany: "Many (8)",
        optLow: "Low",
        optMid: "Normal",
        optHigh: "High",
        optOn: "On",
        optOff: "Off",
        fightBtn: "⚔️ FIGHT!",
        pauseBtn: "⏸️ PAUSE",
        resumeBtn: "▶️ RESUME",
        resetBtn: "🔄 RESET",
        randomBtn: "🎲 RANDOM",
        recLandBtn: "🎬 REC LANDSCAPE",
        recPortBtn: "📱 REC PORTRAIT",
        stopRecBtn: "⏹️ STOP REC",
        replayBtn: "PLAY AGAIN",
        pauseBtn: "⏸️ PAUSE",
        resumeBtn: "▶️ RESUME",
        ready: "Ready",
        start: "FIGHT STARTED!",
        miracleHit: "MIRACLE STRIKE!",
        combo: "COMBO!",
        lightning: "⚡ Lightning Wave!",
        fireball: "🔥 Fireball!",
        ice: "❄️ Blizzard!",
        hammer: "🔨 Holy Hammer!",
        dash: "💨 Shadow Dash!",
        rage: "😤 Berserk Rage active!",
        summon: "💀 Summon Undead!",
        shockwave: "🌊 Shockwave!",
        poison: "🧪 Poison Cloud!",
        wins: "WINS!",
        round: "Round",
        score: "Score",
        dmg: "DMG",
        abilities: "Abilities",
        winMsg: "won Round {round}!",
        finalScore: "Final Score",
        slowMo: "◉ SLOW MOTION",
        meteorMsg: "☄️ METEOR SHOWER! (Sudden Death)",
        laserMsg: "⚡ CAUTION: LASERS ACTIVE!",
        superchatPower: "used Super Power!",
        supportedTeam: "is supported!",
        system: "System",
        connectedPort: "Connected to WebSocket on port {port}.",
        simUser: "Viewer",
        simVip: "Supporter",
        voteStart: "Voting Started! Type team in chat...",
        voteTimer: "{time} seconds left",
        autoMatchStart: "Next Match: {t1} vs {t2}",
        logDamage: "{source} → {target}: {dmg} DMG!",
        logPowerup: "{name} got {type} powerup!",
        logDying: "{name} is dying!",
        logComeback: "Can {name} comeback?!",
        logCombo3: "{name} 3-HIT COMBO!",
        logComboComplete: "{name} completed COMBO!",
        logRecStart: "🎬 {mode} recording started!",
        logRecStop: "⏹️ Recording stopping...",
        logWin: "🏆 {name} won Round {round}! (Score: {s0}-{s1})",
        logRoundStart: "--- Round {round} Started! ---",
        logSuperchat: "{name} SUPERCHAT!",
        minion: "'s minion",
        optLightning: "⚡ Lightning Wave",
        optFireball: "🔥 Fireball",
        optIce: "❄️ Blizzard",
        optHammer: "🔨 Holy Hammer",
        optDash: "💨 Shadow Dash",
        optRage: "😤 Berserk Rage",
        optSummon: "💀 Summon Undead",
        optCombo: "👊 Combo Strike",
        optShockwave: "🌊 Shockwave",
        optPoison: "🧪 Poison Cloud"
    }
};

function t(key, vars={}) {
    let str = langConfig[currentLang][key] || key;
    for (const [k, v] of Object.entries(vars)) {
        str = str.replace(`{${k}}`, v);
    }
    return str;
}

function toggleLanguage() {
    currentLang = currentLang === 'tr' ? 'en' : 'tr';
    const btn = document.getElementById('langBtn');
    if(btn) btn.textContent = currentLang === 'tr' ? '🇹🇷 TR' : '🇬🇧 EN';
    
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (langConfig[currentLang][key]) {
            el.innerHTML = langConfig[currentLang][key];
        }
    });

    // Special handling for dynamic text
    document.getElementById('pauseBtn').innerHTML = paused ? t('resumeBtn') : t('pauseBtn');
    if(document.getElementById('roundDisplay').textContent === t('ready', {}, currentLang==='tr'?'en':'tr') || document.getElementById('roundDisplay').textContent === t('ready')) {
        document.getElementById('roundDisplay').textContent = t('ready');
    }
}

// ═══════════════════════════════════════════════════════
//  RANGE SLIDER SYNC
// ═══════════════════════════════════════════════════════
document.querySelectorAll('input[type="range"]').forEach(rangeEl => {
    const spanEl = document.getElementById(rangeEl.id + 'Val');
    if (spanEl) {
        rangeEl.addEventListener('input', () => {
            let displayVal = rangeEl.value;
            if (rangeEl.id === 'friction') {
                displayVal = (rangeEl.value / 100).toFixed(2);
            } else if (rangeEl.id === 'simSpeed') {
                displayVal = rangeEl.value + 'x';
            }
            spanEl.textContent = displayVal;
        });
    }
});

// ═══════════════════════════════════════════════════════
//  AUDIO ENGINE (Web Audio API — no external files)
// ═══════════════════════════════════════════════════════
let audioCtx = null;

function ensureAudio() {
    if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
}

function isSoundOn() {
    return document.getElementById('soundOn').value === '1';
}

function getVolume() {
    return (+document.getElementById('soundVol').value) / 100;
}

function playSound(type, freq, duration, volume) {
    if (!isSoundOn()) return;
    ensureAudio();

    const vol = volume * getVolume();
    const now = audioCtx.currentTime;

    try {
        // Master gain
        const masterGain = audioCtx.createGain();
        masterGain.gain.setValueAtTime(vol, now);
        masterGain.gain.exponentialRampToValueAtTime(0.001, now + duration);
        masterGain.connect(audioCtx.destination);

        if (type === 'hit') {
            // ── Melee hit: falling sawtooth + noise burst ──
            const osc = audioCtx.createOscillator();
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(freq, now);
            osc.frequency.exponentialRampToValueAtTime(freq * 0.3, now + duration);
            osc.connect(masterGain);
            osc.start(now);
            osc.stop(now + duration);

            // Noise layer for impact feel
            const noiseBuf = audioCtx.createBuffer(1, audioCtx.sampleRate * duration, audioCtx.sampleRate);
            const noiseData = noiseBuf.getChannelData(0);
            for (let i = 0; i < noiseData.length; i++) {
                noiseData[i] = (Math.random() * 2 - 1) * Math.exp(-i / (noiseData.length * 0.15));
            }
            const noiseSource = audioCtx.createBufferSource();
            noiseSource.buffer = noiseBuf;
            const noiseGain = audioCtx.createGain();
            noiseGain.gain.setValueAtTime(vol * 0.6, now);
            noiseGain.gain.exponentialRampToValueAtTime(0.001, now + duration * 0.5);
            noiseSource.connect(noiseGain);
            noiseGain.connect(audioCtx.destination);
            noiseSource.start(now);

        } else if (type === 'zap') {
            // ── Electric zap: rapid frequency changes ──
            const osc = audioCtx.createOscillator();
            osc.type = 'square';
            osc.frequency.setValueAtTime(freq, now);
            osc.frequency.setValueAtTime(freq * 1.5, now + 0.02);
            osc.frequency.setValueAtTime(freq * 0.5, now + 0.05);
            osc.frequency.setValueAtTime(freq * 2, now + 0.08);
            osc.frequency.exponentialRampToValueAtTime(100, now + duration);
            osc.connect(masterGain);
            osc.start(now);
            osc.stop(now + duration);

        } else if (type === 'fire') {
            // ── Fire whoosh: noise + sine mix ──
            const buf = audioCtx.createBuffer(1, audioCtx.sampleRate * duration, audioCtx.sampleRate);
            const data = buf.getChannelData(0);
            for (let i = 0; i < data.length; i++) {
                const t = i / audioCtx.sampleRate;
                data[i] = (Math.random() * 2 - 1) * Math.exp(-t * 4) * Math.sin(t * freq * Math.PI * 2) * 0.5
                         + (Math.random() * 2 - 1) * Math.exp(-t * 6) * 0.5;
            }
            const src = audioCtx.createBufferSource();
            src.buffer = buf;
            src.connect(masterGain);
            src.start(now);

        } else if (type === 'ice') {
            // ── Ice crystal: dual sine descending ──
            const osc1 = audioCtx.createOscillator();
            osc1.type = 'sine';
            osc1.frequency.setValueAtTime(freq * 2, now);
            osc1.frequency.exponentialRampToValueAtTime(freq, now + duration);
            osc1.connect(masterGain);
            osc1.start(now);
            osc1.stop(now + duration);

            const osc2 = audioCtx.createOscillator();
            osc2.type = 'triangle';
            osc2.frequency.setValueAtTime(freq * 3, now);
            osc2.frequency.exponentialRampToValueAtTime(freq * 0.5, now + duration);
            const g2 = audioCtx.createGain();
            g2.gain.setValueAtTime(vol * 0.3, now);
            g2.gain.exponentialRampToValueAtTime(0.001, now + duration);
            osc2.connect(g2);
            g2.connect(audioCtx.destination);
            osc2.start(now);
            osc2.stop(now + duration);

        } else if (type === 'whoosh') {
            // ── Whoosh: bandpass filtered noise sweep ──
            const buf = audioCtx.createBuffer(1, audioCtx.sampleRate * duration, audioCtx.sampleRate);
            const data = buf.getChannelData(0);
            for (let i = 0; i < data.length; i++) {
                const t = i / data.length;
                data[i] = (Math.random() * 2 - 1) * Math.sin(t * Math.PI) * 0.8;
            }
            const src = audioCtx.createBufferSource();
            src.buffer = buf;
            const bp = audioCtx.createBiquadFilter();
            bp.type = 'bandpass';
            bp.frequency.setValueAtTime(freq, now);
            bp.frequency.exponentialRampToValueAtTime(freq * 3, now + duration);
            bp.Q.setValueAtTime(2, now);
            src.connect(bp);
            bp.connect(masterGain);
            src.start(now);

        } else if (type === 'boom') {
            // ── Explosion: deep sine drop + noise burst ──
            const osc = audioCtx.createOscillator();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, now);
            osc.frequency.exponentialRampToValueAtTime(20, now + duration);
            osc.connect(masterGain);
            osc.start(now);
            osc.stop(now + duration);

            const buf = audioCtx.createBuffer(1, audioCtx.sampleRate * duration, audioCtx.sampleRate);
            const data = buf.getChannelData(0);
            for (let i = 0; i < data.length; i++) {
                data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (data.length * 0.08));
            }
            const src = audioCtx.createBufferSource();
            src.buffer = buf;
            const ng = audioCtx.createGain();
            ng.gain.setValueAtTime(vol * 0.8, now);
            ng.gain.exponentialRampToValueAtTime(0.001, now + duration);
            src.connect(ng);
            ng.connect(audioCtx.destination);
            src.start(now);

        } else if (type === 'powerup') {
            // ── Power-up: ascending three notes ──
            const osc = audioCtx.createOscillator();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, now);
            osc.frequency.setValueAtTime(freq * 1.25, now + 0.08);
            osc.frequency.setValueAtTime(freq * 1.5, now + 0.16);
            osc.connect(masterGain);
            osc.start(now);
            osc.stop(now + duration);

        } else if (type === 'death') {
            // ── Death: long descending sawtooth + noise ──
            const osc = audioCtx.createOscillator();
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(freq, now);
            osc.frequency.exponentialRampToValueAtTime(30, now + duration);
            osc.connect(masterGain);
            osc.start(now);
            osc.stop(now + duration);

            const buf = audioCtx.createBuffer(1, audioCtx.sampleRate * duration, audioCtx.sampleRate);
            const data = buf.getChannelData(0);
            for (let i = 0; i < data.length; i++) {
                data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (data.length * 0.3));
            }
            const src = audioCtx.createBufferSource();
            src.buffer = buf;
            const ng = audioCtx.createGain();
            ng.gain.setValueAtTime(vol, now);
            ng.gain.exponentialRampToValueAtTime(0.001, now + duration);
            src.connect(ng);
            ng.connect(audioCtx.destination);
            src.start(now);

        } else if (type === 'bell') {
            // ── Bell tone: sine + harmonic ──
            const osc = audioCtx.createOscillator();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, now);
            osc.connect(masterGain);
            osc.start(now);
            osc.stop(now + duration);

            const osc2 = audioCtx.createOscillator();
            osc2.type = 'sine';
            osc2.frequency.setValueAtTime(freq * 2.01, now);
            const g2 = audioCtx.createGain();
            g2.gain.setValueAtTime(vol * 0.4, now);
            g2.gain.exponentialRampToValueAtTime(0.001, now + duration);
            osc2.connect(g2);
            g2.connect(audioCtx.destination);
            osc2.start(now);
            osc2.stop(now + duration);

        } else if (type === 'clash') {
            // ── Metal clash: noise + resonant sine ──
            const buf = audioCtx.createBuffer(1, audioCtx.sampleRate * duration, audioCtx.sampleRate);
            const data = buf.getChannelData(0);
            for (let i = 0; i < data.length; i++) {
                const t = i / audioCtx.sampleRate;
                data[i] = (
                    (Math.random() * 2 - 1) * Math.exp(-t * 15) +
                    Math.sin(t * freq * Math.PI * 2) * Math.exp(-t * 8) * 0.5
                ) * 0.8;
            }
            const src = audioCtx.createBufferSource();
            src.buffer = buf;
            src.connect(masterGain);
            src.start(now);

        } else if (type === 'summon') {
            // ── Summon: rising and falling triangle ──
            const osc = audioCtx.createOscillator();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(freq * 0.5, now);
            osc.frequency.linearRampToValueAtTime(freq, now + duration * 0.5);
            osc.frequency.linearRampToValueAtTime(freq * 0.5, now + duration);
            osc.connect(masterGain);
            osc.start(now);
            osc.stop(now + duration);

        } else if (type === 'poison') {
            // ── Poison: LFO-modulated sine (bubbly) ──
            const osc = audioCtx.createOscillator();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, now);

            const lfo = audioCtx.createOscillator();
            lfo.frequency.setValueAtTime(8, now);
            const lfoGain = audioCtx.createGain();
            lfoGain.gain.setValueAtTime(50, now);
            lfo.connect(lfoGain);
            lfoGain.connect(osc.frequency);

            osc.connect(masterGain);
            osc.start(now);
            osc.stop(now + duration);
            lfo.start(now);
            lfo.stop(now + duration);

        } else if (type === 'wall') {
            // ── Wall bump: short noise thud ──
            const buf = audioCtx.createBuffer(1, audioCtx.sampleRate * duration, audioCtx.sampleRate);
            const data = buf.getChannelData(0);
            for (let i = 0; i < data.length; i++) {
                data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (data.length * 0.05));
            }
            const src = audioCtx.createBufferSource();
            src.buffer = buf;
            src.connect(masterGain);
            src.start(now);
        }
    } catch (e) {
        // Silently fail if audio context has issues
    }
}


// ═══════════════════════════════════════════════════════
//  GLOBAL STATE
// ═══════════════════════════════════════════════════════
const canvas = document.getElementById('arena');
const ctx = canvas.getContext('2d');
const recCanvas = document.getElementById('recCanvas');
const recCtx = recCanvas.getContext('2d');

let animId = null;
let paused = false;
let gameRunning = false;
let currentRound = 1;
let maxRounds = 3;
let score = [0, 0];
let players = [];
let particles = [];
let projectiles = [];
let obstacles = [];
let minions = [];
let damageNumbers = [];
let powerUps = [];

let screenShake = { x: 0, y: 0, intensity: 0 };
let faceImages = [null, null];
let playerTeams = ['', ''];
let time = 0;
let arenaConfig = {};
let combatLogEl = document.getElementById('combatLog');

// Intro state
let introPhase = false;
let introTimer = 0;

// Slow-motion state
let slowMo = { active: false, factor: 1, timer: 0 };

// Commentary state
let commentary = { text: '', timer: 0, color: '#ffd93d', size: 28, subText: '', subTimer: 0 };

// Match flow control (FIX for infinite scoring)
let matchOver = false;
let roundEndDelay = 0;
let roundEnded = false;  // CRITICAL: prevents multiple death detections per round

// Recording state
let mediaRecorder = null;
let recordedChunks = [];
let isRecording = false;
let recordMode = 'landscape';


// ═══════════════════════════════════════════════════════
//  FOOTBALL TEAM DEFINITIONS
// ═══════════════════════════════════════════════════════
const footballTeams = {
    gs:    { name: 'Galatasaray', short: 'GS',  c1: '#ffd700', c2: '#c0392b', stripe: 'horizontal' },
    fb:    { name: 'Fenerbahçe',  short: 'FB',  c1: '#ffed00', c2: '#00256e', stripe: 'vertical' },
    bjk:   { name: 'Beşiktaş',   short: 'BJK', c1: '#000000', c2: '#ffffff', stripe: 'vertical' },
    ts:    { name: 'Trabzonspor', short: 'TS',  c1: '#6a0032', c2: '#00a6e4', stripe: 'horizontal' },
    rm:    { name: 'Real Madrid', short: 'RM',  c1: '#ffffff', c2: '#febe10', stripe: 'none' },
    barca: { name: 'Barcelona',   short: 'FCB', c1: '#004d98', c2: '#a50044', stripe: 'vertical' },
    liv:   { name: 'Liverpool',   short: 'LFC', c1: '#c8102e', c2: '#ffffff', stripe: 'none' },
    mu:    { name: 'Man United',  short: 'MU',  c1: '#da291c', c2: '#fbe122', stripe: 'none' },
    bay:   { name: 'Bayern',      short: 'BAY', c1: '#dc052d', c2: '#ffffff', stripe: 'none' },
    juv:   { name: 'Juventus',    short: 'JUV', c1: '#000000', c2: '#ffffff', stripe: 'vertical' },
    psg:   { name: 'PSG',         short: 'PSG', c1: '#004170', c2: '#da291c', stripe: 'horizontal' },
    mci:   { name: 'Man City',    short: 'MCI', c1: '#6cabdd', c2: '#ffffff', stripe: 'none' },
    ars:   { name: 'Arsenal',     short: 'ARS', c1: '#ef0107', c2: '#ffffff', stripe: 'none' },
    che:   { name: 'Chelsea',     short: 'CHE', c1: '#034694', c2: '#ffffff', stripe: 'none' },
    acm:   { name: 'AC Milan',    short: 'ACM', c1: '#fb090b', c2: '#000000', stripe: 'vertical' },
    int:   { name: 'Inter',       short: 'INT', c1: '#009de0', c2: '#000000', stripe: 'vertical' },
    bvb:   { name: 'Dortmund',    short: 'BVB', c1: '#fde100', c2: '#000000', stripe: 'none' },
};

function applyTeam(player, teamId) {
    const pf = player === 1 ? 'p1' : 'p2';
    playerTeams[player - 1] = teamId;

    // Clear active states
    document.querySelectorAll(`#teams${player} .team-btn`).forEach(b => b.classList.remove('active'));

    if (teamId && footballTeams[teamId]) {
        const team = footballTeams[teamId];
        document.getElementById(pf + 'name').value = team.name;
        document.getElementById(pf + 'color').value = team.c1;
        if (event && event.target) {
            event.target.classList.add('active');
        }
    }
}


// ═══════════════════════════════════════════════════════
//  COMMENTARY SYSTEM
// ═══════════════════════════════════════════════════════
function getCommentaryPool(type) {
    const pools = {
        tr: {
            bigHit:   ["MUAZZAM VURUŞ!", "BU ÇOK ACITTI!", "İNANILMAZ HASAR!", "NE DARBE AMA!", "YIKILDI!", "KORKUNÇ GÜÇ!"],
            ability:  ["ÖZEL YETENEĞİNİ AÇTI!", "GÜÇ TOPLADI!", "STRATEJİK HAMLE!", "KRİTİK AN!", "BÜYÜ ZAMANI!"],
            lowHp:    ["SON NEFESTE!", "CAN ÇEKİŞİYOR!", "BU İŞ BİTEBİLİR!", "HAYATTA KALMA SAVAŞI!"],
            kill:     ["🏆 KNOCKOUT!", "💀 BİTTİ!", "⚰️ YERE SERDİ!", "🎯 FİNAL VURUŞU!"],
            start:    ["DÖVÜŞ BAŞLASIN!", "HAZIR MIYSINIZ?!", "ARENA KIZIŞIYOR!"],
            powerup:  ["GÜÇLENDİRME ALINDI!", "AVANTAJ ELE GEÇİRİLDİ!", "BONUS!"],
            comeback: ["GERİ DÖNÜŞ MÜ?!", "ASLA PES ETME!", "İMKANSIZI BAŞARIYOR!"]
        },
        en: {
            bigHit:   ["MASSIVE HIT!", "THAT HURT!", "INCREDIBLE DAMAGE!", "WHAT A STRIKE!", "DEVASTATING!", "TERRIFYING POWER!"],
            ability:  ["SPECIAL UNLEASHED!", "GATHERING POWER!", "TACTICAL MOVE!", "CRITICAL MOMENT!", "MAGIC TIME!"],
            lowHp:    ["LAST BREATH!", "CLINGING TO LIFE!", "THIS MIGHT BE IT!", "FIGHT FOR SURVIVAL!"],
            kill:     ["🏆 KNOCKOUT!", "💀 FINISHED!", "⚰️ LAID TO REST!", "🎯 FINAL BLOW!"],
            start:    ["LET THE FIGHT BEGIN!", "ARE YOU READY?!", "ARENA IS HEATING UP!"],
            powerup:  ["POWERUP CLAIMED!", "ADVANTAGE SECURED!", "BONUS!"],
            comeback: ["A COMEBACK?!", "NEVER GIVE UP!", "DOING THE IMPOSSIBLE!"]
        }
    };
    return pools[currentLang][type];
}

function showCommentary(type, extra) {
    if (document.getElementById('commentaryOn').value === '0') return;

    const pool = getCommentaryPool(type);
    if (!pool) return;

    commentary.text = pool[Math.floor(Math.random() * pool.length)];
    commentary.subText = extra || '';
    commentary.timer = 120;
    commentary.subTimer = 120;

    switch (type) {
        case 'bigHit':   commentary.color = '#ff4757'; commentary.size = 32; break;
        case 'ability':  commentary.color = '#ffd93d'; commentary.size = 28; break;
        case 'lowHp':    commentary.color = '#ff6348'; commentary.size = 26; break;
        case 'kill':     commentary.color = '#ff4757'; commentary.size = 40; break;
        case 'start':    commentary.color = '#2ecc71'; commentary.size = 36; break;
        case 'powerup':  commentary.color = '#2ecc71'; commentary.size = 24; break;
        case 'comeback': commentary.color = '#ffd93d'; commentary.size = 30; break;
        default:         commentary.color = '#fff';    commentary.size = 24;
    }
}


// ═══════════════════════════════════════════════════════
//  CHARACTER PRESETS
// ═══════════════════════════════════════════════════════
const presets = {
    wizard:    { name: 'Wizard',       hp: 200, speed: 3, dmg: 12, armor: 5,  size: 25, color: '#9b59b6', ability: 'lightning', abDmg: 45, cd: 5 },
    paladin:   { name: 'Paladin',      hp: 350, speed: 2, dmg: 18, armor: 25, size: 32, color: '#3498db', ability: 'hammer',    abDmg: 55, cd: 6 },
    assassin:  { name: 'Assassin',     hp: 150, speed: 6, dmg: 28, armor: 3,  size: 20, color: '#2d3436', ability: 'dash',      abDmg: 55, cd: 4 },
    berserker: { name: 'Berserker',    hp: 280, speed: 4, dmg: 24, armor: 10, size: 35, color: '#e74c3c', ability: 'rage',      abDmg: 35, cd: 7 },
    necro:     { name: 'Necromancer',   hp: 180, speed: 2, dmg: 10, armor: 8,  size: 25, color: '#1abc9c', ability: 'summon',    abDmg: 18, cd: 8 },
    monk:      { name: 'Monk',         hp: 220, speed: 5, dmg: 18, armor: 12, size: 24, color: '#f39c12', ability: 'combo',     abDmg: 45, cd: 4 }
};

function applyPreset(player, presetName) {
    const p = presets[presetName];
    const pf = player === 1 ? 'p1' : 'p2';

    document.getElementById(pf + 'name').value = p.name;
    document.getElementById(pf + 'hp').value = p.hp;
    document.getElementById(pf + 'speed').value = p.speed;
    document.getElementById(pf + 'dmg').value = p.dmg;
    document.getElementById(pf + 'armor').value = p.armor;
    document.getElementById(pf + 'size').value = p.size;
    document.getElementById(pf + 'color').value = p.color;
    document.getElementById(pf + 'ability').value = p.ability;
    document.getElementById(pf + 'abDmg').value = p.abDmg;
    document.getElementById(pf + 'cd').value = p.cd;

    // Clear team selection
    playerTeams[player - 1] = '';
    document.querySelectorAll(`#teams${player} .team-btn`).forEach(b => b.classList.remove('active'));

    syncAllRanges();
}

function syncAllRanges() {
    document.querySelectorAll('input[type="range"]').forEach(r => {
        const sp = document.getElementById(r.id + 'Val');
        if (sp) {
            let v = r.value;
            if (r.id === 'friction') v = (r.value / 100).toFixed(2);
            else if (r.id === 'simSpeed') v = r.value + 'x';
            sp.textContent = v;
        }
    });
}


// ═══════════════════════════════════════════════════════
//  FACE UPLOAD
// ═══════════════════════════════════════════════════════
function loadFace(playerNum, inputEl) {
    if (inputEl.files && inputEl.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const img = new Image();
            img.onload = function() {
                faceImages[playerNum - 1] = img;
                const preview = document.getElementById('facePreview' + playerNum);
                preview.src = e.target.result;
                preview.style.display = 'block';
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(inputEl.files[0]);
    }
}

function clearFace(playerNum) {
    faceImages[playerNum - 1] = null;
    const preview = document.getElementById('facePreview' + playerNum);
    preview.style.display = 'none';
    preview.src = '';
    document.getElementById('face' + playerNum).value = '';
}


// ═══════════════════════════════════════════════════════
//  READ CONFIGURATION
// ═══════════════════════════════════════════════════════
function makePlayer(prefix, playerId) {
    return {
        id: playerId,
        name: document.getElementById(prefix + 'name').value,
        maxHp: +document.getElementById(prefix + 'hp').value,
        hp: +document.getElementById(prefix + 'hp').value,
        speed: +document.getElementById(prefix + 'speed').value,
        dmg: +document.getElementById(prefix + 'dmg').value,
        armor: +document.getElementById(prefix + 'armor').value,
        size: +document.getElementById(prefix + 'size').value,
        color: document.getElementById(prefix + 'color').value,
        ability: document.getElementById(prefix + 'ability').value,
        abDmg: +document.getElementById(prefix + 'abDmg').value,
        cd: +document.getElementById(prefix + 'cd').value * 60,  // convert seconds to frames
        cdTimer: 0,
        x: playerId === 0 ? 150 : 750,
        y: 250,
        vx: 0,
        vy: 0,
        face: faceImages[playerId],
        team: playerTeams[playerId],
        stunTimer: 0,
        poisonTimer: 0,
        poisonDmg: 0,
        rageActive: false,
        rageTimer: 0,
        comboCount: 0,
        shieldHp: 0,
        aiState: 'chase',
        aiTimer: 0,
        dashTrail: [],
        attackAnim: 0,
        hitFlash: 0,
        angle: 0,
        totalDmgDealt: 0,
        abilitiesUsed: 0,
        alive: true,
        chatDamageMultiplier: 1,
        chatBuffTimer: 0
    };
}

function readConfig() {
    arenaConfig = {
        gravity: +document.getElementById('gravity').value * 0.05,
        friction: +document.getElementById('friction').value / 100,
        obstacleCount: +document.getElementById('obstacles').value,
        simSpeed: +document.getElementById('simSpeed').value,
        aiLevel: +document.getElementById('aiLevel').value,
        type: document.getElementById('arenaType').value
    };
    maxRounds = +document.getElementById('rounds').value;
    return [makePlayer('p1', 0), makePlayer('p2', 1)];
}


// ═══════════════════════════════════════════════════════
//  UTILITY
// ═══════════════════════════════════════════════════════
function dist2d(x1, y1, x2, y2) {
    return Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
}

function lightenColor(hex, amount) {
    let r = parseInt(hex.slice(1, 3), 16);
    let g = parseInt(hex.slice(3, 5), 16);
    let b = parseInt(hex.slice(5, 7), 16);
    r = Math.min(255, r + amount);
    g = Math.min(255, g + amount);
    b = Math.min(255, b + amount);
    return `rgb(${r},${g},${b})`;
}


// ═══════════════════════════════════════════════════════
//  OBSTACLES
// ═══════════════════════════════════════════════════════
function generateObstacles() {
    obstacles = [];
    const count = arenaConfig.obstacleCount;

    for (let i = 0; i < count; i++) {
        let tries = 0;
        let ob;
        do {
            ob = {
                x: 120 + Math.random() * 660,
                y: 80 + Math.random() * 340,
                w: 25 + Math.random() * 40,
                h: 25 + Math.random() * 40,
                type: Math.random() > 0.5 ? 'rect' : 'circle',
                r: 18 + Math.random() * 20
            };
            tries++;
        } while (
            tries < 30 &&
            (dist2d(ob.x, ob.y, 150, 250) < 100 || dist2d(ob.x, ob.y, 750, 250) < 100)
        );
        obstacles.push(ob);
    }
}


// ═══════════════════════════════════════════════════════
//  POWER-UPS
// ═══════════════════════════════════════════════════════
class PowerUp {
    constructor() {
        this.x = 80 + Math.random() * 740;
        this.y = 60 + Math.random() * 380;
        this.type = ['health', 'damage', 'speed', 'shield'][Math.floor(Math.random() * 4)];
        this.life = 600;
        this.size = 12;
        this.bobPhase = Math.random() * Math.PI * 2;

        // Avoid spawning inside obstacles
        for (const ob of obstacles) {
            const cx = ob.type === 'circle' ? ob.x : ob.x + ob.w / 2;
            const cy = ob.type === 'circle' ? ob.y : ob.y + ob.h / 2;
            if (dist2d(this.x, this.y, cx, cy) < 60) {
                this.x = 80 + Math.random() * 740;
                this.y = 60 + Math.random() * 380;
            }
        }
    }

    update() {
        this.life--;
        this.bobPhase += 0.05;
    }

    draw(c) {
        const alpha = this.life < 60 ? this.life / 60 : 1;
        const bob = Math.sin(this.bobPhase) * 4;
        c.globalAlpha = alpha;

        let clr;
        switch (this.type) {
            case 'health': clr = '#2ecc71'; break;
            case 'damage': clr = '#e74c3c'; break;
            case 'speed':  clr = '#3498db'; break;
            case 'shield': clr = '#f39c12'; break;
        }

        // Glow
        const glow = c.createRadialGradient(this.x, this.y + bob, 0, this.x, this.y + bob, this.size * 2);
        glow.addColorStop(0, clr + '88');
        glow.addColorStop(1, clr + '00');
        c.fillStyle = glow;
        c.beginPath();
        c.arc(this.x, this.y + bob, this.size * 2, 0, Math.PI * 2);
        c.fill();

        // Core
        c.fillStyle = clr;
        c.beginPath();
        c.arc(this.x, this.y + bob, this.size, 0, Math.PI * 2);
        c.fill();

        // Icon
        c.fillStyle = '#fff';
        c.font = 'bold 10px Arial';
        c.textAlign = 'center';
        c.textBaseline = 'middle';
        const icons = { health: '♥', damage: '⚔', speed: '»', shield: '◆' };
        c.fillText(icons[this.type], this.x, this.y + bob);

        c.globalAlpha = 1;
    }
}

function checkPowerUpPickup() {
    for (let i = powerUps.length - 1; i >= 0; i--) {
        const pu = powerUps[i];
        for (const p of players) {
            if (!p.alive) continue;
            if (dist2d(p.x, p.y, pu.x, pu.y) < p.size + pu.size) {
                switch (pu.type) {
                    case 'health':
                        p.hp = Math.min(p.maxHp, p.hp + 40);
                        damageNumbers.push(new DamageNumber(p.x, p.y - p.size - 10, '+40 HP', '#2ecc71'));
                        break;
                    case 'damage':
                        p.dmg += 8;
                        setTimeout(() => { p.dmg -= 8; }, 5000);
                        damageNumbers.push(new DamageNumber(p.x, p.y - p.size - 10, '+DMG!', '#e74c3c'));
                        break;
                    case 'speed':
                        p.speed += 2;
                        setTimeout(() => { p.speed -= 2; }, 4000);
                        damageNumbers.push(new DamageNumber(p.x, p.y - p.size - 10, '+SPD!', '#3498db'));
                        break;
                    case 'shield':
                        p.shieldHp += 30;
                        damageNumbers.push(new DamageNumber(p.x, p.y - p.size - 10, '+SHIELD', '#f39c12'));
                        break;
                }
                spawnParticles(pu.x, pu.y, '#ffd93d', 12, 3, 20, 3, 'circle');
                showCommentary('powerup', p.name + ' güçlenme aldı!');
                addLog(t('logPowerup', {name: p.name, type: pu.type}), 'powerup');
                playSound('powerup', 523, 0.3, 0.3);
                powerUps.splice(i, 1);
                break;
            }
        }
    }
}


// ═══════════════════════════════════════════════════════
//  COMBAT LOG
// ═══════════════════════════════════════════════════════
function addLog(msg, type = 'info') {
    const p = document.createElement('p');
    p.className = 'log-' + type;
    p.textContent = `[${(time / 60).toFixed(1)}s] ${msg}`;
    combatLogEl.appendChild(p);
    combatLogEl.scrollTop = combatLogEl.scrollHeight;
}


// ═══════════════════════════════════════════════════════
//  PARTICLE SYSTEM
// ═══════════════════════════════════════════════════════
class Particle {
    constructor(x, y, color, vx, vy, life, size, type = 'circle') {
        this.x = x;
        this.y = y;
        this.color = color;
        this.vx = vx;
        this.vy = vy;
        this.life = life;
        this.maxLife = life;
        this.size = size;
        this.type = type;
    }

    update() {
        this.x += this.vx;
        this.y += this.vy;
        this.vy += arenaConfig.gravity * 0.3;
        this.life--;
        this.vx *= 0.98;
        this.vy *= 0.98;
    }

    draw(c) {
        const alpha = this.life / this.maxLife;
        c.globalAlpha = alpha;

        if (this.type === 'spark') {
            c.strokeStyle = this.color;
            c.lineWidth = this.size;
            c.beginPath();
            c.moveTo(this.x, this.y);
            c.lineTo(this.x - this.vx * 3, this.y - this.vy * 3);
            c.stroke();
        } else if (this.type === 'ring') {
            c.strokeStyle = this.color;
            c.lineWidth = 2;
            const expansion = (1 - alpha) * 60;
            c.beginPath();
            c.arc(this.x, this.y, this.size + expansion, 0, Math.PI * 2);
            c.stroke();
        } else if (this.type === 'confetti') {
            c.fillStyle = this.color;
            c.save();
            c.translate(this.x, this.y);
            c.rotate(this.life * 0.1);
            c.fillRect(-this.size, -this.size * 0.5, this.size * 2, this.size);
            c.restore();
        } else {
            c.fillStyle = this.color;
            c.beginPath();
            c.arc(this.x, this.y, this.size * alpha, 0, Math.PI * 2);
            c.fill();
        }

        c.globalAlpha = 1;
    }
}

function spawnParticles(x, y, color, count, speed, life, size, type) {
    for (let i = 0; i < count; i++) {
        const angle = Math.random() * Math.PI * 2;
        const spd = Math.random() * speed;
        particles.push(new Particle(
            x, y, color,
            Math.cos(angle) * spd, Math.sin(angle) * spd,
            life + Math.random() * 20, size, type
        ));
    }
}

function spawnConfetti(x, y, color) {
    const colors = ['#ff4757', '#ffd93d', '#2ecc71', '#3498db', '#9b59b6', '#e74c3c', '#1abc9c', '#f39c12'];
    for (let i = 0; i < 40; i++) {
        const angle = Math.random() * Math.PI * 2;
        const spd = 2 + Math.random() * 5;
        particles.push(new Particle(
            x, y,
            color || colors[Math.floor(Math.random() * colors.length)],
            Math.cos(angle) * spd, Math.sin(angle) * spd - 3,
            120 + Math.random() * 60, 3 + Math.random() * 3, 'confetti'
        ));
    }
}


// ═══════════════════════════════════════════════════════
//  DAMAGE NUMBERS
// ═══════════════════════════════════════════════════════
class DamageNumber {
    constructor(x, y, text, color) {
        this.x = x;
        this.y = y;
        this.text = text;
        this.color = color;
        this.life = 80;
        this.maxLife = 80;
        this.vy = -1.5;
    }

    update() {
        this.y += this.vy;
        this.vy *= 0.97;
        this.life--;
    }

    draw(c) {
        const alpha = this.life / this.maxLife;
        const scale = 0.5 + alpha * 0.5;
        c.globalAlpha = alpha;
        c.fillStyle = this.color;
        c.font = `bold ${14 * scale + 8}px Arial`;
        c.textAlign = 'center';
        c.strokeStyle = '#000';
        c.lineWidth = 3;
        c.strokeText(this.text, this.x, this.y);
        c.fillText(this.text, this.x, this.y);
        c.globalAlpha = 1;
    }
}


// ═══════════════════════════════════════════════════════
//  PROJECTILE
// ═══════════════════════════════════════════════════════
class Projectile {
    constructor(x, y, vx, vy, owner, type, dmg, radius) {
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.vy = vy;
        this.owner = owner;
        this.type = type;
        this.dmg = dmg;
        this.radius = radius || 8;
        this.life = 240;
        this.trail = [];
    }

    update() {
        this.trail.push({ x: this.x, y: this.y });
        if (this.trail.length > 12) this.trail.shift();

        this.x += this.vx;
        this.y += this.vy;
        this.life--;

        // Trail particles
        if (this.type === 'fireball') {
            spawnParticles(this.x, this.y, '#ff6348', 1, 0.8, 15, 3, 'circle');
        }
        if (this.type === 'ice') {
            spawnParticles(this.x, this.y, '#74b9ff', 1, 0.4, 10, 2, 'circle');
        }

        // Wall bounce
        if (this.x < 0 || this.x > canvas.width) this.vx *= -1;
        if (this.y < 0 || this.y > canvas.height) this.vy *= -1;
    }

    draw(c) {
        // Trail
        for (let i = 0; i < this.trail.length; i++) {
            const alpha = i / this.trail.length * 0.4;
            c.globalAlpha = alpha;
            let clr = '#fff';
            if (this.type === 'fireball') clr = '#ff6348';
            else if (this.type === 'ice') clr = '#74b9ff';
            else if (this.type === 'hammer') clr = '#ffd93d';
            else if (this.type === 'poison') clr = '#00b894';
            c.fillStyle = clr;
            c.beginPath();
            c.arc(this.trail[i].x, this.trail[i].y, this.radius * 0.4, 0, Math.PI * 2);
            c.fill();
        }
        c.globalAlpha = 1;

        // Main projectile body
        if (this.type === 'fireball') {
            const g = c.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.radius);
            g.addColorStop(0, '#ffd93d');
            g.addColorStop(0.5, '#ff6348');
            g.addColorStop(1, '#c0392b');
            c.fillStyle = g;
            c.beginPath();
            c.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            c.fill();

        } else if (this.type === 'ice') {
            c.fillStyle = '#74b9ff';
            c.strokeStyle = '#fff';
            c.lineWidth = 2;
            c.beginPath();
            for (let i = 0; i < 6; i++) {
                const a = (Math.PI / 3) * i + time * 0.03;
                const px = this.x + Math.cos(a) * this.radius;
                const py = this.y + Math.sin(a) * this.radius;
                i === 0 ? c.moveTo(px, py) : c.lineTo(px, py);
            }
            c.closePath();
            c.fill();
            c.stroke();

        } else if (this.type === 'hammer') {
            c.save();
            c.translate(this.x, this.y);
            c.rotate(time * 0.1);
            c.fillStyle = '#8B4513';
            c.fillRect(-3, -12, 6, 18);
            c.fillStyle = '#ffd93d';
            c.fillRect(-8, -16, 16, 8);
            c.globalAlpha = 0.5;
            c.fillStyle = '#fff';
            c.fillRect(-6, -14, 4, 4);
            c.globalAlpha = 1;
            c.restore();

        } else if (this.type === 'poison') {
            c.fillStyle = 'rgba(0,184,148,0.6)';
            c.beginPath();
            c.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            c.fill();
            c.fillStyle = '#00b894';
            c.beginPath();
            c.arc(
                this.x + Math.sin(time * 0.08) * 3,
                this.y + Math.cos(time * 0.08) * 3,
                this.radius * 0.5, 0, Math.PI * 2
            );
            c.fill();
        }
    }
}


// ═══════════════════════════════════════════════════════
//  MINION
// ═══════════════════════════════════════════════════════
class Minion {
    constructor(x, y, owner, life) {
        this.x = x;
        this.y = y;
        this.owner = owner;
        this.life = life;
        this.maxLife = life;
        this.size = 10;
        this.hp = 30;
        this.dmg = 6;
        this.speed = 1.5;
        this.attackCd = 0;
    }

    update(target) {
        const dx = target.x - this.x;
        const dy = target.y - this.y;
        const d = Math.sqrt(dx * dx + dy * dy);

        if (d > 0) {
            this.x += (dx / d) * this.speed;
            this.y += (dy / d) * this.speed;
        }

        this.life--;
        if (this.attackCd > 0) this.attackCd--;

        if (d < target.size + this.size && this.attackCd <= 0) {
            dealDamage(target, this.dmg, players[this.owner].name + " " + t('minion'));
            this.attackCd = 60;
        }
    }

    draw(c) {
        const alpha = Math.min(1, this.life / 30);
        c.globalAlpha = alpha;
        c.fillStyle = '#2ecc71';
        c.strokeStyle = '#27ae60';
        c.lineWidth = 1;
        c.beginPath();
        c.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        c.fill();
        c.stroke();
        // Eyes
        c.fillStyle = '#000';
        c.beginPath();
        c.arc(this.x - 3, this.y - 2, 2, 0, Math.PI * 2);
        c.arc(this.x + 3, this.y - 2, 2, 0, Math.PI * 2);
        c.fill();
        c.globalAlpha = 1;
    }
}


// ═══════════════════════════════════════════════════════
//  DAMAGE SYSTEM (with round-end guard)
// ═══════════════════════════════════════════════════════
function dealDamage(target, rawDmg, source) {
    // ── GUARD: Don't deal damage if round already ended or target dead ──
    if (!target.alive || roundEnded) return;

    const attacker = players[1 - target.id];
    if (attacker && attacker.chatBuffTimer > 0) {
        rawDmg *= attacker.chatDamageMultiplier;
    }

    let dmg = Math.max(1, rawDmg - target.armor * 0.3);

    // Shield absorption
    if (target.shieldHp > 0) {
        const absorbed = Math.min(target.shieldHp, dmg);
        target.shieldHp -= absorbed;
        dmg -= absorbed;
        playSound('clash', 800, 0.1, 0.15);
    }

    dmg = Math.round(dmg);
    target.hp -= dmg;
    target.hitFlash = 12;
    screenShake.intensity = Math.min(12, dmg * 0.25);

    // Track stats
    if (attacker) attacker.totalDmgDealt += dmg;

    // Damage number
    damageNumbers.push(new DamageNumber(
        target.x + (Math.random() - 0.5) * 20,
        target.y - target.size - 10,
        '-' + dmg,
        '#ff4757'
    ));

    addLog(t('logDamage', {source: source, target: target.name, dmg: dmg}), 'damage');

    // Hit sound (pitch & volume scale with damage)
    playSound('hit', 200 + dmg * 3, 0.15 + dmg * 0.002, Math.min(0.5, 0.15 + dmg * 0.008));

    // Knockback
    if (attacker) {
        const knockDir = Math.atan2(target.y - attacker.y, target.x - attacker.x);
        target.vx += Math.cos(knockDir) * dmg * 0.12;
        target.vy += Math.sin(knockDir) * dmg * 0.12;
    }

    // Hit particles
    spawnParticles(target.x, target.y, target.color, 6, 2.5, 20, 3, 'circle');

    // Big hit commentary + boom sound
    if (dmg > 30) {
        showCommentary('bigHit', source + ' → ' + dmg + ' ' + t('dmg') + '!');
        playSound('boom', 80, 0.4, 0.4);
    }

    // Auto slow-mo on big hits
    if (dmg > 35 && document.getElementById('slowMoOn').value === '1') {
        slowMo.active = true;
        slowMo.factor = 0.2;
        slowMo.timer = 40;
    }

    // Low HP warning
    if (target.hp > 0 && target.hp < target.maxHp * 0.2) {
        showCommentary('lowHp', t('logDying', {name: target.name}));
    }

    // Comeback detection
    if (attacker && attacker.hp < attacker.maxHp * 0.3 && target.hp > target.maxHp * 0.5) {
        showCommentary('comeback', t('logComeback', {name: attacker.name}));
    }
}


// ═══════════════════════════════════════════════════════
//  AI SYSTEM (improved obstacle avoidance)
// ═══════════════════════════════════════════════════════
function getObstacleAvoidance(player) {
    let avoidX = 0, avoidY = 0;

    for (const ob of obstacles) {
        let centerX, centerY, avoidDist;

        if (ob.type === 'circle') {
            centerX = ob.x;
            centerY = ob.y;
            avoidDist = ob.r + player.size + 30;
        } else {
            centerX = ob.x + ob.w / 2;
            centerY = ob.y + ob.h / 2;
            avoidDist = Math.max(ob.w, ob.h) / 2 + player.size + 30;
        }

        const dx = player.x - centerX;
        const dy = player.y - centerY;
        const d = Math.sqrt(dx * dx + dy * dy);

        if (d < avoidDist && d > 0) {
            const force = (avoidDist - d) / avoidDist * 2;
            avoidX += (dx / d) * force;
            avoidY += (dy / d) * force;
        }
    }

    // Wall Avoidance (Corner Stuck Fix)
    const wallDist = player.size + 50;
    if (player.x < wallDist) avoidX += (wallDist - player.x) / wallDist * 2.5;
    if (player.x > canvas.width - wallDist) avoidX -= (player.x - (canvas.width - wallDist)) / wallDist * 2.5;
    if (player.y < wallDist) avoidY += (wallDist - player.y) / wallDist * 2.5;
    if (player.y > canvas.height - wallDist) avoidY -= (player.y - (canvas.height - wallDist)) / wallDist * 2.5;

    return { x: avoidX, y: avoidY };
}

function hasLineOfSight(p1, p2) {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;

    for (let t = 0; t < 1; t += 0.1) {
        const px = p1.x + dx * t;
        const py = p1.y + dy * t;

        for (const ob of obstacles) {
            if (ob.type === 'circle') {
                if (dist2d(px, py, ob.x, ob.y) < ob.r + 5) return false;
            } else {
                if (px > ob.x - 5 && px < ob.x + ob.w + 5 &&
                    py > ob.y - 5 && py < ob.y + ob.h + 5) return false;
            }
        }
    }
    return true;
}

function updateAI(player, enemy) {
    // ── Guards ──
    if (!player.alive || roundEnded) return;

    const dx = enemy.x - player.x;
    const dy = enemy.y - player.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const aiLvl = arenaConfig.aiLevel;

    player.angle = Math.atan2(dy, dx);

    // Stun check
    if (player.stunTimer > 0) {
        player.stunTimer--;
        return;
    }

    // Poison tick
    if (player.poisonTimer > 0) {
        player.poisonTimer--;
        if (time % 40 === 0) {
            player.hp -= player.poisonDmg;
            damageNumbers.push(new DamageNumber(player.x, player.y - player.size, '-' + player.poisonDmg, '#00b894'));
            spawnParticles(player.x, player.y, '#00b894', 2, 1, 15, 2, 'circle');
        }
    }

    // Rage timer
    if (player.rageTimer > 0) {
        player.rageTimer--;
        if (player.rageTimer <= 0) player.rageActive = false;
    }

    // ── AI state decision ──
    player.aiTimer--;
    if (player.aiTimer <= 0) {
        player.aiTimer = 40 + Math.random() * 60 / aiLvl;

        const isRanged = ['lightning', 'fireball', 'ice', 'poison'].includes(player.ability);
        const isMelee = ['hammer', 'dash', 'combo', 'rage'].includes(player.ability);

        if (isRanged) {
            if (dist < 120) player.aiState = 'flee';
            else if (dist < 350) player.aiState = player.cdTimer <= 0 ? 'attack' : 'kite';
            else player.aiState = 'chase';
        } else if (isMelee) {
            if (dist > 250) player.aiState = 'chase';
            else if (dist < 90) player.aiState = 'attack';
            else player.aiState = 'chase';
        } else {
            if (dist < 180) player.aiState = player.cdTimer <= 0 ? 'attack' : 'flee';
            else player.aiState = 'chase';
        }

        // High AI dodges when low HP
        if (aiLvl >= 3 && player.hp < player.maxHp * 0.3) {
            player.aiState = Math.random() > 0.4 ? 'flee' : player.aiState;
        }
    }

    // ── Movement ──
    let moveX = 0, moveY = 0;
    const speed = player.speed * (player.rageActive ? 1.4 : 1);

    switch (player.aiState) {
        case 'chase':
            if (dist > 0) { moveX = dx / dist; moveY = dy / dist; }
            break;
        case 'flee':
            if (dist > 0) { moveX = -dx / dist; moveY = -dy / dist; }
            break;
        case 'kite':
            const perpX = -dy / dist;
            const perpY = dx / dist;
            moveX = perpX * 0.7 + (dist < 200 ? -dx / dist * 0.4 : dx / dist * 0.3);
            moveY = perpY * 0.7 + (dist < 200 ? -dy / dist * 0.4 : dy / dist * 0.3);
            break;
        case 'attack':
            if (dist > 60) { moveX = dx / dist; moveY = dy / dist; }
            break;
    }

    // Randomness
    moveX += (Math.random() - 0.5) * 0.25 / aiLvl;
    moveY += (Math.random() - 0.5) * 0.25 / aiLvl;

    // Obstacle avoidance
    const avoid = getObstacleAvoidance(player);
    moveX += avoid.x;
    moveY += avoid.y;

    // Normalize
    const moveLen = Math.sqrt(moveX * moveX + moveY * moveY);
    if (moveLen > 0) {
        moveX /= moveLen;
        moveY /= moveLen;
    }

    player.vx += moveX * speed * 0.15;
    player.vy += moveY * speed * 0.15;

    // ── Melee auto-attack ──
    if (dist < player.size + enemy.size + 12 && enemy.alive) {
        const attackInterval = Math.max(25, 55 - player.speed * 3);
        if (time % attackInterval === 0) {
            let actualDmg = player.dmg * (player.rageActive ? 2 : 1);
            
            // Desperation Strike (Surprise hit)
            if (player.hp < player.maxHp * 0.15 && Math.random() < 0.05) {
                actualDmg *= 4;
                showCommentary('bigHit', t('miracleHit'));
                playSound('boom', 50, 0.6, 0.5);
                if(typeof screenShake !== 'undefined') screenShake.intensity = 15;
                spawnParticles(enemy.x, enemy.y, '#e74c3c', 30, 6, 40, 5, 'spark');
                addLog(`⚠️ ${player.name} ${t('miracleHit')}!`, 'ability');
            }
            dealDamage(enemy, actualDmg, player.name);
            player.attackAnim = 18;
            playSound('clash', 300 + Math.random() * 200, 0.12, 0.25);
            spawnParticles(
                (player.x + enemy.x) / 2,
                (player.y + enemy.y) / 2,
                '#ffd93d', 5, 2, 15, 2, 'spark'
            );

            // Combo ability
            if (player.ability === 'combo') {
                player.comboCount++;
                if (player.comboCount >= 3) {
                    dealDamage(enemy, player.abDmg, player.name + ' ' + t('combo'));
                    player.comboCount = 0;
                    spawnParticles(enemy.x, enemy.y, '#f39c12', 20, 4, 25, 4, 'spark');
                    showCommentary('ability', t('logCombo3', {name: player.name}));
                    playSound('boom', 120, 0.35, 0.5);
                    addLog(t('logComboComplete', {name: player.name}), 'ability');
                }
            }
        }
    } else {
        // Decay combo if not in melee
        player.comboCount = Math.max(0, player.comboCount - (time % 150 === 0 ? 1 : 0));
    }

    // ── ABILITY USAGE ──
    if (player.cdTimer > 0) player.cdTimer--;

    if (player.cdTimer <= 0 && !roundEnded) {
        let used = false;
        const lineOfSight = hasLineOfSight(player, enemy);

        switch (player.ability) {
            case 'lightning':
                if (dist < 220 && lineOfSight) {
                    addLog( + t('lightning'), 'ability');
                    showCommentary('ability', t('lightning').toUpperCase());
                    player.abilitiesUsed++;
                    playSound('zap', 600, 0.4, 0.4);
                    spawnParticles(player.x, player.y, '#9b59b6', 25, 5, 30, 3, 'spark');
                    particles.push(new Particle(player.x, player.y, '#e8daef', 0, 0, 25, 30, 'ring'));
                    if (dist < 200) {
                        dealDamage(enemy, player.abDmg, t('optLightning'));
                        enemy.stunTimer = 25;
                        for (let i = 0; i < 6; i++) {
                            const t = i / 6;
                            spawnParticles(
                                player.x + dx * t + (Math.random() - 0.5) * 25,
                                player.y + dy * t + (Math.random() - 0.5) * 25,
                                '#a29bfe', 2, 2, 15, 2, 'spark'
                            );
                        }
                    }
                    used = true;
                }
                break;

            case 'fireball':
                if (dist > 70 && lineOfSight) {
                    addLog( + t('fireball'), 'ability');
                    showCommentary('ability', t('fireball').toUpperCase());
                    player.abilitiesUsed++;
                    playSound('fire', 200, 0.35, 0.35);
                    const fbAngle = Math.atan2(dy, dx);
                    projectiles.push(new Projectile(
                        player.x, player.y,
                        Math.cos(fbAngle) * 3.5, Math.sin(fbAngle) * 3.5,
                        player.id, 'fireball', player.abDmg, 10
                    ));
                    spawnParticles(player.x, player.y, '#ff6348', 8, 2.5, 20, 3, 'circle');
                    used = true;
                }
                break;

            case 'ice':
                if (dist > 60 && lineOfSight) {
                    addLog( + t('ice'), 'ability');
                    showCommentary('ability', t('ice').toUpperCase());
                    player.abilitiesUsed++;
                    playSound('ice', 1200, 0.3, 0.3);
                    for (let i = 0; i < 3; i++) {
                        const iceAngle = Math.atan2(dy, dx) + (i - 1) * 0.3;
                        projectiles.push(new Projectile(
                            player.x, player.y,
                            Math.cos(iceAngle) * 3, Math.sin(iceAngle) * 3,
                            player.id, 'ice', player.abDmg * 0.4, 7
                        ));
                    }
                    spawnParticles(player.x, player.y, '#74b9ff', 12, 2.5, 20, 3, 'circle');
                    used = true;
                }
                break;

            case 'hammer':
                if (dist > 60 && dist < 400 && lineOfSight) {
                    addLog( + t('hammer'), 'ability');
                    showCommentary('ability', t('hammer').toUpperCase());
                    player.abilitiesUsed++;
                    playSound('whoosh', 400, 0.25, 0.3);
                    const hamAngle = Math.atan2(dy, dx);
                    projectiles.push(new Projectile(
                        player.x, player.y,
                        Math.cos(hamAngle) * 4.5, Math.sin(hamAngle) * 4.5,
                        player.id, 'hammer', player.abDmg, 12
                    ));
                    used = true;
                }
                break;

            case 'dash':
                if (dist < 300 && dist > 50) {
                    addLog( + t('dash'), 'ability');
                    showCommentary('ability', t('dash').toUpperCase());
                    player.abilitiesUsed++;
                    playSound('whoosh', 600, 0.2, 0.35);
                    const dashDist = Math.min(dist - enemy.size, 130);
                    const oldX = player.x, oldY = player.y;
                    player.x += (dx / dist) * dashDist;
                    player.y += (dy / dist) * dashDist;
                    // Resolve obstacle collision after teleport
                    for (const ob of obstacles) resolveObstacleCollision(player, ob);
                    dealDamage(enemy, player.abDmg, t('optDash'));
                    spawnParticles(player.x, player.y, '#636e72', 15, 3, 25, 3, 'circle');
                    for (let i = 0; i < 6; i++) {
                        player.dashTrail.push({
                            x: oldX + (player.x - oldX) * (i / 6),
                            y: oldY + (player.y - oldY) * (i / 6),
                            life: 25
                        });
                    }
                    used = true;
                }
                break;

            case 'rage':
                addLog( + t('rage'), 'ability');
                showCommentary('ability', t('rage').toUpperCase());
                player.abilitiesUsed++;
                playSound('boom', 60, 0.5, 0.4);
                player.rageActive = true;
                player.rageTimer = 360;
                spawnParticles(player.x, player.y, '#e74c3c', 20, 4, 30, 4, 'circle');
                particles.push(new Particle(player.x, player.y, '#e74c3c', 0, 0, 25, 25, 'ring'));
                used = true;
                break;

            case 'summon':
                addLog( + t('summon'), 'ability');
                showCommentary('ability', t('summon').toUpperCase());
                player.abilitiesUsed++;
                playSound('summon', 200, 0.5, 0.3);
                for (let i = 0; i < 3; i++) {
                    const angle = (Math.PI * 2 / 3) * i + Math.random();
                    minions.push(new Minion(
                        player.x + Math.cos(angle) * 40,
                        player.y + Math.sin(angle) * 40,
                        player.id, 360
                    ));
                }
                spawnParticles(player.x, player.y, '#2ecc71', 12, 3, 25, 3, 'circle');
                used = true;
                break;

            case 'combo':
                // Passive — handled in melee section above
                break;

            case 'shockwave':
                if (dist < 220) {
                    addLog( + t('shockwave'), 'ability');
                    showCommentary('ability', t('shockwave').toUpperCase());
                    player.abilitiesUsed++;
                    playSound('boom', 100, 0.4, 0.5);
                    particles.push(new Particle(player.x, player.y, '#ffd93d', 0, 0, 30, 20, 'ring'));
                    particles.push(new Particle(player.x, player.y, '#ff6348', 0, 0, 25, 35, 'ring'));
                    if (dist < 170) {
                        dealDamage(enemy, player.abDmg, t('optShockwave'));
                        enemy.vx += (dx / dist) * 12;
                        enemy.vy += (dy / dist) * 12;
                        enemy.stunTimer = 35;
                    }
                    spawnParticles(player.x, player.y, '#ffeaa7', 20, 5, 25, 3, 'spark');
                    used = true;
                }
                break;

            case 'poison':
                if (dist > 50 && lineOfSight) {
                    addLog( + t('poison'), 'ability');
                    showCommentary('ability', t('poison').toUpperCase());
                    player.abilitiesUsed++;
                    playSound('poison', 300, 0.4, 0.25);
                    const posAngle = Math.atan2(dy, dx);
                    projectiles.push(new Projectile(
                        player.x, player.y,
                        Math.cos(posAngle) * 2.5, Math.sin(posAngle) * 2.5,
                        player.id, 'poison', player.abDmg * 0.3, 15
                    ));
                    used = true;
                }
                break;
        }

        if (used) player.cdTimer = player.cd;
    }
}


// ═══════════════════════════════════════════════════════
//  PHYSICS (multi-pass obstacle resolution)
// ═══════════════════════════════════════════════════════
function resolveObstacleCollision(player, ob) {
    if (ob.type === 'circle') {
        const dx = player.x - ob.x;
        const dy = player.y - ob.y;
        const d = Math.sqrt(dx * dx + dy * dy);
        const minDist = player.size + ob.r + 2;

        if (d < minDist && d > 0) {
            const overlap = minDist - d;
            const nx = dx / d;
            const ny = dy / d;
            
            player.x += nx * overlap;
            player.y += ny * overlap;

            const dot = player.vx * nx + player.vy * ny;
            if (dot < 0) {
                const restitution = 0.5;
                player.vx -= (1 + restitution) * dot * nx;
                player.vy -= (1 + restitution) * dot * ny;
                playSound('wall', 150, 0.06, 0.1);
            }
        }
    } else {
        // Rectangle collision
        const closestX = Math.max(ob.x, Math.min(player.x, ob.x + ob.w));
        const closestY = Math.max(ob.y, Math.min(player.y, ob.y + ob.h));
        const dx = player.x - closestX;
        const dy = player.y - closestY;
        const d = Math.sqrt(dx * dx + dy * dy);

        if (d < player.size + 2) {
            let nx = 0, ny = 0, overlap = 0;
            
            if (d > 0) {
                nx = dx / d;
                ny = dy / d;
                overlap = (player.size + 2) - d;
            } else {
                // Stuck inside
                const cx = ob.x + ob.w / 2;
                const cy = ob.y + ob.h / 2;
                const rx = player.x - cx;
                const ry = player.y - cy;
                
                if (Math.abs(rx) / (ob.w / 2) > Math.abs(ry) / (ob.h / 2)) {
                    nx = Math.sign(rx) || 1;
                    ny = 0;
                    overlap = (ob.w / 2) - Math.abs(rx) + player.size + 2;
                } else {
                    nx = 0;
                    ny = Math.sign(ry) || 1;
                    overlap = (ob.h / 2) - Math.abs(ry) + player.size + 2;
                }
            }

            player.x += nx * overlap;
            player.y += ny * overlap;

            const dot = player.vx * nx + player.vy * ny;
            if (dot < 0) {
                const restitution = 0.4;
                player.vx -= (1 + restitution) * dot * nx;
                player.vy -= (1 + restitution) * dot * ny;
                playSound('wall', 180, 0.05, 0.08);
            }
        }
    }
}

function updatePhysics(player) {
    if (!player.alive) return;

    if (player.chatBuffTimer > 0) {
        player.chatBuffTimer--;
        if (player.chatBuffTimer <= 0) {
            player.chatDamageMultiplier = 1;
        } else if (time % 8 === 0) {
            particles.push(new Particle(
                player.x + (Math.random() - 0.5) * player.size * 2,
                player.y + (Math.random() - 0.5) * player.size * 2,
                player.id === 0 ? '#ff4757' : '#3742fa',
                0, -2, 4, 20, 'star'
            ));
        }
    }

    // Dynamically adjust friction and gravity based on arena
    let currentFriction = arenaConfig.friction;
    let currentGravity = arenaConfig.gravity;
    
    if (arenaConfig.type === 'moon') {
        currentFriction = 0.99; // very low friction
        currentGravity = 0.05;  // very low gravity
    } else if (arenaConfig.type === 'swamp') {
        currentFriction = 0.85; // high friction (slows down)
        currentGravity = 0.3;
    }

    // Friction and gravity
    player.vx *= currentFriction;
    player.vy *= currentFriction;
    player.vy += currentGravity;

    // Apply velocity
    player.x += player.vx;
    player.y += player.vy;

    // Wall collision
    let hitWall = false;
    const restitution = 0.6;
    
    if (player.x - player.size < 0) {
        player.x = player.size;
        player.vx = Math.abs(player.vx) * restitution;
        hitWall = true;
    }
    if (player.x + player.size > canvas.width) {
        player.x = canvas.width - player.size;
        player.vx = -Math.abs(player.vx) * restitution;
        hitWall = true;
    }
    if (player.y - player.size < 0) {
        player.y = player.size;
        player.vy = Math.abs(player.vy) * restitution;
        hitWall = true;
    }
    if (player.y + player.size > canvas.height) {
        player.y = canvas.height - player.size;
        player.vy = -Math.abs(player.vy) * restitution;
        hitWall = true;
    }

    if (hitWall && (Math.abs(player.vx) > 2 || Math.abs(player.vy) > 2)) {
        playSound('wall', 120, 0.06, 0.1);
    }

    // Obstacle collision (single pass due to exact resolution)
    for (const ob of obstacles) {
        resolveObstacleCollision(player, ob);
    }

    // Update timers
    player.dashTrail = player.dashTrail.filter(t => { t.life--; return t.life > 0; });
    if (player.attackAnim > 0) player.attackAnim--;
    if (player.hitFlash > 0) player.hitFlash--;
}

function playerCollision(p1, p2) {
    if (!p1.alive || !p2.alive) return;

    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const d = Math.sqrt(dx * dx + dy * dy);
    const minDist = p1.size + p2.size;

    if (d < minDist && d > 0) {
        const nx = dx / d;
        const ny = dy / d;
        const overlap = minDist - d;

        // Separate
        p1.x -= nx * overlap * 0.5;
        p1.y -= ny * overlap * 0.5;
        p2.x += nx * overlap * 0.5;
        p2.y += ny * overlap * 0.5;

        // Elastic collision
        const relVx = p1.vx - p2.vx;
        const relVy = p1.vy - p2.vy;
        const relDotN = relVx * nx + relVy * ny;

        if (relDotN > 0) {
            const m1 = p1.size;
            const m2 = p2.size;
            const impulse = (2 * relDotN) / (m1 + m2);
            p1.vx -= impulse * m2 * nx * 0.7;
            p1.vy -= impulse * m2 * ny * 0.7;
            p2.vx += impulse * m1 * nx * 0.7;
            p2.vy += impulse * m1 * ny * 0.7;

            spawnParticles((p1.x + p2.x) / 2, (p1.y + p2.y) / 2, '#ffd93d', 4, 2.5, 15, 2, 'spark');
            playSound('clash', 250 + Math.random() * 150, 0.1, 0.2);
        }
    }
}

function checkProjectileHits() {
    for (let i = projectiles.length - 1; i >= 0; i--) {
        const proj = projectiles[i];
        const target = players[1 - proj.owner];

        if (!target.alive) {
            projectiles.splice(i, 1);
            continue;
        }

        const d = dist2d(target.x, target.y, proj.x, proj.y);

        // Hit target
        if (d < target.size + proj.radius) {
            dealDamage(target, proj.dmg, proj.type.toUpperCase());

            if (proj.type === 'ice') {
                target.stunTimer = 30;
                spawnParticles(target.x, target.y, '#74b9ff', 12, 3, 20, 3, 'circle');
                playSound('ice', 800, 0.2, 0.3);
            } else if (proj.type === 'fireball') {
                spawnParticles(target.x, target.y, '#ff6348', 18, 4, 25, 4, 'circle');
                spawnParticles(target.x, target.y, '#ffd93d', 8, 3, 20, 3, 'spark');
                playSound('boom', 100, 0.3, 0.4);
            } else if (proj.type === 'hammer') {
                target.vx += (proj.x < target.x ? 1 : -1) * 7;
                target.vy -= 4;
                spawnParticles(target.x, target.y, '#ffd93d', 12, 3, 20, 3, 'spark');
                playSound('hit', 150, 0.2, 0.4);
            } else if (proj.type === 'poison') {
                target.poisonTimer = 240;
                target.poisonDmg = Math.round(proj.dmg * 0.25);
                spawnParticles(target.x, target.y, '#00b894', 10, 2.5, 25, 3, 'circle');
                playSound('poison', 200, 0.3, 0.2);
            }

            projectiles.splice(i, 1);
            continue;
        }

        // Hit obstacle
        let hitObstacle = false;
        for (const ob of obstacles) {
            if (ob.type === 'circle') {
                if (dist2d(proj.x, proj.y, ob.x, ob.y) < ob.r + proj.radius) hitObstacle = true;
            } else {
                if (proj.x > ob.x - proj.radius && proj.x < ob.x + ob.w + proj.radius &&
                    proj.y > ob.y - proj.radius && proj.y < ob.y + ob.h + proj.radius) hitObstacle = true;
            }
        }
        if (hitObstacle) {
            spawnParticles(proj.x, proj.y, '#ffd93d', 6, 2.5, 15, 2, 'spark');
            playSound('wall', 200, 0.08, 0.15);
            projectiles.splice(i, 1);
            continue;
        }

        // Lifetime expired
        if (proj.life <= 0) {
            projectiles.splice(i, 1);
        }
    }
}


// ═══════════════════════════════════════════════════════
//  DRAWING FUNCTIONS
// ═══════════════════════════════════════════════════════

// ── Arena Background ──
function drawArena(c) {
    const type = arenaConfig.type;

    switch (type) {
        case 'stone':
            c.fillStyle = '#1a1a2e';
            c.fillRect(0, 0, canvas.width, canvas.height);
            c.strokeStyle = 'rgba(255,255,255,0.03)';
            c.lineWidth = 1;
            for (let x = 0; x < canvas.width; x += 40) {
                c.beginPath(); c.moveTo(x, 0); c.lineTo(x, canvas.height); c.stroke();
            }
            for (let y = 0; y < canvas.height; y += 40) {
                c.beginPath(); c.moveTo(0, y); c.lineTo(canvas.width, y); c.stroke();
            }
            break;

        case 'lava':
            c.fillStyle = '#1a0000';
            c.fillRect(0, 0, canvas.width, canvas.height);
            for (let i = 0; i < 5; i++) {
                const lx = (Math.sin(time * 0.008 + i) * 0.5 + 0.5) * canvas.width;
                const ly = (Math.cos(time * 0.01 + i * 2) * 0.5 + 0.5) * canvas.height;
                const g = c.createRadialGradient(lx, ly, 0, lx, ly, 80);
                g.addColorStop(0, 'rgba(255,69,0,0.12)');
                g.addColorStop(1, 'rgba(255,69,0,0)');
                c.fillStyle = g;
                c.fillRect(0, 0, canvas.width, canvas.height);
            }
            break;

        case 'ice':
            const iceGrad = c.createLinearGradient(0, 0, canvas.width, canvas.height);
            iceGrad.addColorStop(0, '#0c3547');
            iceGrad.addColorStop(1, '#1a3a4a');
            c.fillStyle = iceGrad;
            c.fillRect(0, 0, canvas.width, canvas.height);
            c.fillStyle = 'rgba(200,230,255,0.03)';
            for (let i = 0; i < 20; i++) {
                const fx = (Math.sin(i * 37 + time * 0.002) * 0.5 + 0.5) * canvas.width;
                const fy = (Math.cos(i * 53 + time * 0.0015) * 0.5 + 0.5) * canvas.height;
                c.beginPath();
                c.arc(fx, fy, 20, 0, Math.PI * 2);
                c.fill();
            }
            break;

        case 'forest':
            c.fillStyle = '#0a1a0a';
            c.fillRect(0, 0, canvas.width, canvas.height);
            c.fillStyle = 'rgba(0,80,0,0.04)';
            for (let i = 0; i < 15; i++) {
                c.beginPath();
                c.arc((i * 47) % canvas.width, (i * 73) % canvas.height, 25 + Math.sin(time * 0.008 + i) * 4, 0, Math.PI * 2);
                c.fill();
            }
            break;

        case 'void':
            c.fillStyle = '#050510';
            c.fillRect(0, 0, canvas.width, canvas.height);
            c.fillStyle = '#fff';
            for (let i = 0; i < 40; i++) {
                c.globalAlpha = 0.3 + Math.sin(time * 0.03 + i) * 0.3;
                c.beginPath();
                c.arc(
                    (i * 137 + Math.sin(time * 0.0008 + i) * 2) % canvas.width,
                    (i * 97 + Math.cos(time * 0.0008 + i) * 2) % canvas.height,
                    1, 0, Math.PI * 2
                );
                c.fill();
            }
            c.globalAlpha = 1;
            const voidGrad = c.createRadialGradient(canvas.width / 2, canvas.height / 2, 50, canvas.width / 2, canvas.height / 2, 300);
            voidGrad.addColorStop(0, 'rgba(100,0,150,0.04)');
            voidGrad.addColorStop(1, 'rgba(0,0,50,0)');
            c.fillStyle = voidGrad;
            c.fillRect(0, 0, canvas.width, canvas.height);
            break;

        case 'colosseum':
            c.fillStyle = '#1a1510';
            c.fillRect(0, 0, canvas.width, canvas.height);
            c.fillStyle = 'rgba(139,119,101,0.08)';
            for (let i = 0; i < 8; i++) {
                const pa = (Math.PI * 2 / 8) * i;
                const px = canvas.width / 2 + Math.cos(pa) * 220;
                const py = canvas.height / 2 + Math.sin(pa) * 180;
                c.fillRect(px - 8, py - 30, 16, 60);
            }
            c.strokeStyle = 'rgba(139,119,101,0.12)';
            c.lineWidth = 2;
            c.beginPath();
            c.ellipse(canvas.width / 2, canvas.height / 2, 230, 190, 0, 0, Math.PI * 2);
            c.stroke();
            break;

        case 'moon':
            c.fillStyle = '#111111';
            c.fillRect(0, 0, canvas.width, canvas.height);
            c.fillStyle = 'rgba(255,255,255,0.05)';
            for(let i=0; i<30; i++) {
                c.beginPath();
                c.arc((i*113)%canvas.width, (i*89)%canvas.height, Math.random()*2+1, 0, Math.PI*2);
                c.fill();
            }
            c.fillStyle = 'rgba(100,100,100,0.1)';
            for(let i=0; i<5; i++) {
                c.beginPath();
                c.arc((i*200)%canvas.width, (i*150)%canvas.height, 40+i*10, 0, Math.PI*2);
                c.fill();
            }
            break;

        case 'swamp':
            c.fillStyle = '#1a2b1a';
            c.fillRect(0, 0, canvas.width, canvas.height);
            c.fillStyle = 'rgba(50,200,50,0.05)';
            for(let i=0; i<20; i++) {
                const sx = (Math.sin(time*0.005+i)*0.5+0.5)*canvas.width;
                const sy = (Math.cos(time*0.004+i*3)*0.5+0.5)*canvas.height;
                c.beginPath();
                c.arc(sx, sy, 30+Math.sin(time*0.01)*10, 0, Math.PI*2);
                c.fill();
            }
            break;

        case 'cyberpunk':
            c.fillStyle = '#050510';
            c.fillRect(0, 0, canvas.width, canvas.height);
            c.strokeStyle = 'rgba(0,255,255,0.1)';
            c.lineWidth = 2;
            for(let x=0; x<canvas.width; x+=50) {
                c.beginPath(); c.moveTo(x, 0); c.lineTo(x, canvas.height); c.stroke();
            }
            c.strokeStyle = 'rgba(255,0,255,0.1)';
            for(let y=0; y<canvas.height; y+=50) {
                c.beginPath(); c.moveTo(0, y); c.lineTo(canvas.width, y); c.stroke();
            }
            // Background neon glow
            const cg = c.createRadialGradient(canvas.width/2, canvas.height/2, 50, canvas.width/2, canvas.height/2, 400);
            cg.addColorStop(0, 'rgba(0,255,255,0.05)');
            cg.addColorStop(1, 'rgba(255,0,255,0.0)');
            c.fillStyle = cg;
            c.fillRect(0, 0, canvas.width, canvas.height);
            break;
    }

    // Arena border
    c.strokeStyle = 'rgba(255,255,255,0.08)';
    c.lineWidth = 2;
    c.strokeRect(2, 2, canvas.width - 4, canvas.height - 4);
}

// ── Obstacles ──
function drawObstacles(c) {
    for (const ob of obstacles) {
        let color1, color2;
        switch (arenaConfig.type) {
            case 'lava':    color1 = '#4a0000'; color2 = '#2a0000'; break;
            case 'ice':     color1 = '#2a5a6a'; color2 = '#1a3a4a'; break;
            case 'forest':  color1 = '#2a4a1a'; color2 = '#1a3a0a'; break;
            case 'void':    color1 = '#2a1a3a'; color2 = '#1a0a2a'; break;
            case 'moon':    color1 = '#444455'; color2 = '#222233'; break;
            case 'swamp':   color1 = '#2a3b2a'; color2 = '#1a2a1a'; break;
            case 'cyberpunk':color1 = '#003333'; color2 = '#001111'; break;
            default:        color1 = '#333';    color2 = '#222';
        }

        if (ob.type === 'circle') {
            const g = c.createRadialGradient(ob.x, ob.y, 0, ob.x, ob.y, ob.r);
            g.addColorStop(0, color1);
            g.addColorStop(1, color2);
            c.fillStyle = g;
            c.beginPath();
            c.arc(ob.x, ob.y, ob.r, 0, Math.PI * 2);
            c.fill();
            c.strokeStyle = 'rgba(255,255,255,0.08)';
            c.lineWidth = 1;
            c.stroke();
        } else {
            c.fillStyle = color1;
            c.fillRect(ob.x, ob.y, ob.w, ob.h);
            c.strokeStyle = 'rgba(255,255,255,0.08)';
            c.lineWidth = 1;
            c.strokeRect(ob.x, ob.y, ob.w, ob.h);
        }
    }
}

// ── Team Ball Drawing ──
function drawTeamBall(c, p, teamId) {
    const team = footballTeams[teamId];
    if (!team) return false;

    c.save();

    // Primary color
    c.fillStyle = team.c1;
    c.beginPath();
    c.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    c.fill();

    // Stripe pattern
    c.save();
    c.beginPath();
    c.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    c.clip();

    if (team.stripe === 'vertical') {
        c.fillStyle = team.c2;
        for (let i = -2; i <= 2; i += 2) {
            c.fillRect(p.x + i * (p.size * 0.35) - p.size * 0.15, -p.size + p.y, p.size * 0.3, p.size * 2);
        }
    } else if (team.stripe === 'horizontal') {
        c.fillStyle = team.c2;
        for (let i = -2; i <= 2; i += 2) {
            c.fillRect(p.x - p.size, p.y + i * (p.size * 0.35) - p.size * 0.15, p.size * 2, p.size * 0.3);
        }
    }
    c.restore();

    // Border
    c.strokeStyle = team.c2;
    c.lineWidth = 2.5;
    c.beginPath();
    c.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    c.stroke();

    // Team short name
    c.fillStyle = '#fff';
    c.strokeStyle = '#000';
    c.lineWidth = 2;
    c.font = `bold ${Math.max(8, p.size * 0.45)}px Arial`;
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.strokeText(team.short, p.x, p.y);
    c.fillText(team.short, p.x, p.y);

    c.restore();
    return true;
}

// ── Player Drawing ──
function drawPlayer(c, p) {
    // Dead player ghost
    if (!p.alive) {
        c.globalAlpha = 0.2;
        c.fillStyle = '#555';
        c.beginPath();
        c.arc(p.x, p.y, p.size * 0.5, 0, Math.PI * 2);
        c.fill();
        c.globalAlpha = 1;
        return;
    }

    c.save();

    // Dash trail (afterimages)
    for (const trail of p.dashTrail) {
        c.globalAlpha = trail.life / 25 * 0.3;
        c.fillStyle = p.color;
        c.beginPath();
        c.arc(trail.x, trail.y, p.size, 0, Math.PI * 2);
        c.fill();
    }
    c.globalAlpha = 1;

    // Motion trail
    if (Math.abs(p.vx) > 1 || Math.abs(p.vy) > 1) {
        c.globalAlpha = 0.15;
        c.fillStyle = p.color;
        c.beginPath();
        c.arc(p.x - p.vx * 2, p.y - p.vy * 2, p.size * 0.8, 0, Math.PI * 2);
        c.fill();
        c.globalAlpha = 0.07;
        c.beginPath();
        c.arc(p.x - p.vx * 4, p.y - p.vy * 4, p.size * 0.6, 0, Math.PI * 2);
        c.fill();
        c.globalAlpha = 1;
    }

    // Rage aura
    if (p.rageActive) {
        const rageSize = p.size + 8 + Math.sin(time * 0.15) * 4;
        c.strokeStyle = 'rgba(231,76,60,0.4)';
        c.lineWidth = 3;
        c.beginPath();
        c.arc(p.x, p.y, rageSize, 0, Math.PI * 2);
        c.stroke();
        if (time % 3 === 0) {
            spawnParticles(
                p.x + (Math.random() - 0.5) * p.size * 2,
                p.y + (Math.random() - 0.5) * p.size * 2,
                '#e74c3c', 1, 0.8, 10, 2, 'circle'
            );
        }
    }

    // Poison indicator
    if (p.poisonTimer > 0) {
        c.strokeStyle = 'rgba(0,184,148,0.35)';
        c.lineWidth = 2;
        c.setLineDash([3, 3]);
        c.beginPath();
        c.arc(p.x, p.y, p.size + 5, 0, Math.PI * 2);
        c.stroke();
        c.setLineDash([]);
    }

    // Shield
    if (p.shieldHp > 0) {
        c.strokeStyle = 'rgba(100,200,255,0.4)';
        c.lineWidth = 3;
        c.beginPath();
        c.arc(p.x, p.y, p.size + 4, 0, Math.PI * 2);
        c.stroke();
    }

    // Hit flash
    if (p.hitFlash > 0 && p.hitFlash % 3 === 0) {
        c.globalAlpha = 0.4;
    }

    // ── Main body: Team logo or default sphere ──
    let drewTeam = false;
    if (p.team) {
        drewTeam = drawTeamBall(c, p, p.team);
    }

    if (!drewTeam) {
        const bodyGrad = c.createRadialGradient(p.x - p.size * 0.3, p.y - p.size * 0.3, 0, p.x, p.y, p.size);
        bodyGrad.addColorStop(0, lightenColor(p.color, 40));
        bodyGrad.addColorStop(1, p.color);
        c.fillStyle = bodyGrad;
        c.beginPath();
        c.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        c.fill();
        c.strokeStyle = lightenColor(p.color, 60);
        c.lineWidth = 2;
        c.stroke();
    }

    // ── Face image or drawn face ──
    if (p.face) {
        c.save();
        c.beginPath();
        c.arc(p.x, p.y, p.size - 2, 0, Math.PI * 2);
        c.clip();
        c.drawImage(p.face, p.x - p.size + 2, p.y - p.size + 2, (p.size - 2) * 2, (p.size - 2) * 2);
        c.restore();
    } else if (!drewTeam) {
        // Eyes
        const eyeOffset = p.size * 0.3;
        const eyeSize = p.size * 0.12;

        c.fillStyle = '#fff';
        c.beginPath();
        c.arc(p.x - eyeOffset, p.y - eyeSize, eyeSize, 0, Math.PI * 2);
        c.arc(p.x + eyeOffset, p.y - eyeSize, eyeSize, 0, Math.PI * 2);
        c.fill();

        // Pupils (look at enemy)
        const enemy = players[1 - p.id];
        if (enemy) {
            const lookAngle = Math.atan2(enemy.y - p.y, enemy.x - p.x);
            const pupilDist = eyeSize * 0.4;
            c.fillStyle = '#000';
            c.beginPath();
            c.arc(p.x - eyeOffset + Math.cos(lookAngle) * pupilDist, p.y - eyeSize + Math.sin(lookAngle) * pupilDist, eyeSize * 0.6, 0, Math.PI * 2);
            c.arc(p.x + eyeOffset + Math.cos(lookAngle) * pupilDist, p.y - eyeSize + Math.sin(lookAngle) * pupilDist, eyeSize * 0.6, 0, Math.PI * 2);
            c.fill();
        }

        // Mouth (changes with HP)
        const hpPct = p.hp / p.maxHp;
        c.strokeStyle = '#fff';
        c.lineWidth = 1.5;
        c.beginPath();
        if (hpPct > 0.5) {
            c.arc(p.x, p.y + p.size * 0.1, p.size * 0.25, 0.1 * Math.PI, 0.9 * Math.PI);
        } else if (hpPct > 0.2) {
            c.moveTo(p.x - p.size * 0.2, p.y + p.size * 0.3);
            c.lineTo(p.x + p.size * 0.2, p.y + p.size * 0.3);
        } else {
            c.arc(p.x, p.y + p.size * 0.5, p.size * 0.2, 1.1 * Math.PI, 1.9 * Math.PI);
        }
        c.stroke();
    }

    c.globalAlpha = 1;

    // Attack swing animation
    if (p.attackAnim > 0) {
        const swingAngle = p.angle + Math.sin(p.attackAnim / 18 * Math.PI) * 1.5;
        c.strokeStyle = '#ffd93d';
        c.lineWidth = 3;
        c.globalAlpha = p.attackAnim / 18;
        c.beginPath();
        c.arc(p.x, p.y, p.size + 15, swingAngle - 0.5, swingAngle + 0.5);
        c.stroke();
        c.globalAlpha = 1;
    }

    // Cooldown indicator ring
    if (p.cdTimer > 0) {
        const cdPct = p.cdTimer / p.cd;
        c.strokeStyle = 'rgba(255,255,255,0.25)';
        c.lineWidth = 2;
        c.beginPath();
        c.arc(p.x, p.y, p.size + 3, -Math.PI / 2, -Math.PI / 2 + (1 - cdPct) * Math.PI * 2);
        c.stroke();
    }

    // Name tag
    c.fillStyle = '#fff';
    c.strokeStyle = '#000';
    c.lineWidth = 2;
    c.font = 'bold 10px Arial';
    c.textAlign = 'center';
    c.strokeText(p.name, p.x, p.y - p.size - 18);
    c.fillText(p.name, p.x, p.y - p.size - 18);

    // Mini HP bar
    const barWidth = p.size * 2;
    const barHeight = 4;
    const barX = p.x - barWidth / 2;
    const barY = p.y - p.size - 12;
    c.fillStyle = 'rgba(0,0,0,0.5)';
    c.fillRect(barX, barY, barWidth, barHeight);
    const hpPct = Math.max(0, p.hp / p.maxHp);
    c.fillStyle = hpPct > 0.5 ? '#2ecc71' : hpPct > 0.25 ? '#f39c12' : '#e74c3c';
    c.fillRect(barX, barY, barWidth * hpPct, barHeight);

    // Stun stars
    if (p.stunTimer > 0) {
        c.fillStyle = '#ffd93d';
        c.font = '11px Arial';
        for (let i = 0; i < 3; i++) {
            const starAngle = time * 0.08 + (Math.PI * 2 / 3) * i;
            c.fillText('★', p.x + Math.cos(starAngle) * (p.size + 10), p.y - p.size - 5 + Math.sin(starAngle) * 5);
        }
    }

    c.restore();
}

// ── Lightning Effect ──
function drawLightning(c, x1, y1, x2, y2) {
    // Outer glow
    c.strokeStyle = '#a29bfe';
    c.lineWidth = 2;
    c.globalAlpha = 0.7;
    c.beginPath();
    c.moveTo(x1, y1);
    for (let i = 1; i < 8; i++) {
        const t = i / 8;
        c.lineTo(
            x1 + (x2 - x1) * t + (Math.random() - 0.5) * 30,
            y1 + (y2 - y1) * t + (Math.random() - 0.5) * 30
        );
    }
    c.lineTo(x2, y2);
    c.stroke();

    // Bright core
    c.strokeStyle = '#dfe6e9';
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(x1, y1);
    for (let i = 1; i < 8; i++) {
        const t = i / 8;
        c.lineTo(
            x1 + (x2 - x1) * t + (Math.random() - 0.5) * 15,
            y1 + (y2 - y1) * t + (Math.random() - 0.5) * 15
        );
    }
    c.lineTo(x2, y2);
    c.stroke();
    c.globalAlpha = 1;
}

// ── Commentary Overlay ──
function drawCommentary(c) {
    if (commentary.timer <= 0) return;
    commentary.timer--;

    const alpha = Math.min(1, commentary.timer / 20);
    const y = 60 + Math.sin(time * 0.03) * 5;

    c.globalAlpha = alpha;
    c.fillStyle = commentary.color;
    c.strokeStyle = '#000';
    c.lineWidth = 4;
    c.font = `bold ${commentary.size}px Arial`;
    c.textAlign = 'center';
    c.strokeText(commentary.text, canvas.width / 2, y);
    c.fillText(commentary.text, canvas.width / 2, y);

    if (commentary.subText && commentary.subTimer > 0) {
        commentary.subTimer--;
        c.font = 'bold 14px Arial';
        c.fillStyle = '#ddd';
        c.strokeText(commentary.subText, canvas.width / 2, y + 25);
        c.fillText(commentary.subText, canvas.width / 2, y + 25);
    }

    c.globalAlpha = 1;
}

// ── Canvas HUD (for recording) ──
function drawHUDOnCanvas(c) {
    const p1 = players[0], p2 = players[1];
    if (!p1 || !p2) return;

    // P1 HP bar (top-left)
    c.fillStyle = 'rgba(0,0,0,0.6)';
    c.fillRect(10, 8, 200, 22);
    c.fillStyle = p1.color;
    c.fillRect(12, 10, 196 * Math.max(0, p1.hp / p1.maxHp), 18);
    c.fillStyle = '#fff';
    c.font = 'bold 11px Arial';
    c.textAlign = 'left';
    c.fillText(`${p1.name}: ${Math.max(0, Math.round(p1.hp))}/${p1.maxHp}`, 15, 24);

    // P2 HP bar (top-right)
    c.fillStyle = 'rgba(0,0,0,0.6)';
    c.fillRect(canvas.width - 210, 8, 200, 22);
    c.fillStyle = p2.color;
    c.fillRect(canvas.width - 208, 10, 196 * Math.max(0, p2.hp / p2.maxHp), 18);
    c.fillStyle = '#fff';
    c.textAlign = 'right';
    c.fillText(`${p2.name}: ${Math.max(0, Math.round(p2.hp))}/${p2.maxHp}`, canvas.width - 15, 24);

    // Round info (top-center)
    c.textAlign = 'center';
    c.font = 'bold 12px Arial';
    c.fillStyle = '#ffd93d';
    c.fillText(`R${currentRound}/${maxRounds}  ${score[0]}-${score[1]}`, canvas.width / 2, 22);

    // Timer (bottom-center)
    c.font = '10px Arial';
    c.fillStyle = '#aaa';
    c.fillText(`${(time / 60).toFixed(0)}s`, canvas.width / 2, canvas.height - 8);

    // REC indicator
    if (isRecording) {
        c.fillStyle = '#e74c3c';
        c.beginPath();
        c.arc(canvas.width - 20, canvas.height - 15, 5, 0, Math.PI * 2);
        c.fill();
        c.fillStyle = '#fff';
        c.font = 'bold 9px Arial';
        c.textAlign = 'right';
        c.fillText('REC', canvas.width - 28, canvas.height - 11);
    }
}


// ═══════════════════════════════════════════════════════
//  INTRO ANIMATION
// ═══════════════════════════════════════════════════════
function runIntro() {
    if (paused) {
        animId = requestAnimationFrame(runIntro);
        return;
    }

    introTimer++;
    const p1 = players[0], p2 = players[1];
    const progress = Math.min(1, introTimer / 90);
    const ease = 1 - Math.pow(1 - progress, 3);

    p1.x = -50 + 200 * ease;
    p1.y = 250;
    p2.x = canvas.width + 50 - 200 * ease;
    p2.y = 250;

    ctx.save();
    drawArena(ctx);
    drawObstacles(ctx);
    drawPlayer(ctx, p1);
    drawPlayer(ctx, p2);

    // VS text
    if (progress < 0.8) {
        const vsAlpha = Math.min(1, progress * 2);
        ctx.globalAlpha = vsAlpha;
        ctx.fillStyle = '#ff4757';
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 4;
        ctx.font = 'bold 48px Arial';
        ctx.textAlign = 'center';
        ctx.strokeText('VS', canvas.width / 2, canvas.height / 2);
        ctx.fillText('VS', canvas.width / 2, canvas.height / 2);
        ctx.font = 'bold 16px Arial';
        ctx.fillStyle = '#ffd93d';
        ctx.fillText(p1.name, canvas.width / 2 - 80, canvas.height / 2 + 30);
        ctx.fillText(p2.name, canvas.width / 2 + 80, canvas.height / 2 + 30);
        ctx.globalAlpha = 1;
    }

    // Countdown
    if (progress >= 0.8) {
        const countPhase = (introTimer - 72) / 30;
        let countText = '';
        if (countPhase < 1) countText = '3';
        else if (countPhase < 2) countText = '2';
        else if (countPhase < 3) countText = '1';
        else countText = 'SAVAŞ!';

        ctx.globalAlpha = Math.max(0.3, 1 - (countPhase % 1));
        ctx.fillStyle = countText === 'SAVAŞ!' ? '#2ecc71' : '#fff';
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 4;
        ctx.font = 'bold 60px Arial';
        ctx.textAlign = 'center';
        ctx.strokeText(countText, canvas.width / 2, canvas.height / 2);
        ctx.fillText(countText, canvas.width / 2, canvas.height / 2);
        ctx.globalAlpha = 1;

        // Countdown bell sounds
        if (introTimer === 72)  playSound('bell', 523, 0.3, 0.3);
        if (introTimer === 102) playSound('bell', 523, 0.3, 0.3);
        if (introTimer === 132) playSound('bell', 523, 0.3, 0.3);
        if (introTimer === 162) playSound('bell', 784, 0.5, 0.5);
    }

    drawHUDOnCanvas(ctx);
    ctx.restore();

    if (isRecording) recordFrame();

    if (introTimer >= 180) {
        introPhase = false;
        p1.x = 150; p1.y = 250;
        p2.x = 750; p2.y = 250;
        showCommentary('start');
        addLog(t('start'), 'info');
        gameLoop();
        return;
    }

    animId = requestAnimationFrame(runIntro);
}


// ═══════════════════════════════════════════════════════
//  SCREEN SHAKE
// ═══════════════════════════════════════════════════════
function updateScreenShake() {
    if (screenShake.intensity > 0) {
        screenShake.x = (Math.random() - 0.5) * screenShake.intensity;
        screenShake.y = (Math.random() - 0.5) * screenShake.intensity;
        screenShake.intensity *= 0.88;
        if (screenShake.intensity < 0.5) screenShake.intensity = 0;
    } else {
        screenShake.x = 0;
        screenShake.y = 0;
    }
}


// ═══════════════════════════════════════════════════════
//  HTML HUD UPDATE
// ═══════════════════════════════════════════════════════
function updateHUD() {
    const p1 = players[0], p2 = players[1];

    document.getElementById('p1nameDisplay').textContent = p1.name;
    document.getElementById('p2nameDisplay').textContent = p2.name;
    document.getElementById('p1nameDisplay').style.color = p1.color;
    document.getElementById('p2nameDisplay').style.color = p2.color;

    const hp1pct = Math.max(0, p1.hp / p1.maxHp * 100);
    const hp2pct = Math.max(0, p2.hp / p2.maxHp * 100);

    document.getElementById('p1hpBar').style.width = hp1pct + '%';
    document.getElementById('p2hpBar').style.width = hp2pct + '%';
    document.getElementById('p1hpText').textContent = `${Math.max(0, Math.round(p1.hp))}/${p1.maxHp}`;
    document.getElementById('p2hpText').textContent = `${Math.max(0, Math.round(p2.hp))}/${p2.maxHp}`;

    document.getElementById('roundDisplay').textContent =
        `Round ${currentRound} / ${maxRounds} | Skor: ${score[0]} - ${score[1]}`;
}


// ═══════════════════════════════════════════════════════
//  VIDEO RECORDING
// ═══════════════════════════════════════════════════════
function startRecording(mode) {
    if (isRecording) return;

    recordMode = mode;
    isRecording = true;
    recordedChunks = [];

    // Set canvas dimensions for recording orientation
    if (mode === 'portrait') {
        recCanvas.width = 540;
        recCanvas.height = 960;
    } else {
        recCanvas.width = 960;
        recCanvas.height = 540;
    }

    const stream = recCanvas.captureStream(30);
    let options = { mimeType: 'video/webm;codecs=vp9' };

    try {
        mediaRecorder = new MediaRecorder(stream, options);
    } catch (e) {
        options = { mimeType: 'video/webm' };
        try {
            mediaRecorder = new MediaRecorder(stream, options);
        } catch (e2) {
            alert('Tarayıcınız video kaydını desteklemiyor.');
            isRecording = false;
            return;
        }
    }

    mediaRecorder.ondataavailable = e => {
        if (e.data.size > 0) recordedChunks.push(e.data);
    };

    mediaRecorder.onstop = () => {
        const blob = new Blob(recordedChunks, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `arena_${mode}_${Date.now()}.webm`;
        a.click();
        URL.revokeObjectURL(url);

        isRecording = false;
        document.getElementById('recLandBtn').style.display = '';
        document.getElementById('recPortBtn').style.display = '';
        document.getElementById('stopRecBtn').style.display = 'none';
        document.getElementById('recLandBtn').classList.remove('recording');
        document.getElementById('recPortBtn').classList.remove('recording');
    };

    mediaRecorder.start(100);
    document.getElementById('stopRecBtn').style.display = '';

    if (mode === 'landscape') {
        document.getElementById('recLandBtn').classList.add('recording');
        document.getElementById('recPortBtn').style.display = 'none';
    } else {
        document.getElementById('recPortBtn').classList.add('recording');
        document.getElementById('recLandBtn').style.display = 'none';
    }

    addLog(t('logRecStart', {mode: mode==='portrait' ? 'Portrait' : 'Landscape'}), 'info');
}

function stopRecording() {
    if (!isRecording || !mediaRecorder) return;
    mediaRecorder.stop();
    addLog(t('logRecStop'), 'info');
}

function recordFrame() {
    if (!isRecording) return;

    const rc = recCtx;
    const p1 = players[0], p2 = players[1];

    if (recordMode === 'landscape') {
        // ── LANDSCAPE: Scale arena to 960x540 ──
        rc.fillStyle = '#0a0a0f';
        rc.fillRect(0, 0, 960, 540);

        const scaleX = 960 / canvas.width;
        const scaleY = 540 / canvas.height;
        const scale = Math.min(scaleX, scaleY);
        const offsetX = (960 - canvas.width * scale) / 2;
        const offsetY = (540 - canvas.height * scale) / 2;

        rc.save();
        rc.translate(offsetX, offsetY);
        rc.scale(scale, scale);

        drawArena(rc);
        drawObstacles(rc);
        for (const m of minions) m.draw(rc);
        for (const pr of projectiles) pr.draw(rc);
        for (const pt of particles) pt.draw(rc);
        for (const pu of powerUps) pu.draw(rc);
        drawPlayer(rc, p1);
        drawPlayer(rc, p2);
        for (const dn of damageNumbers) dn.draw(rc);
        for (const p of players) {
            if (p.alive && p.ability === 'lightning' && p.cdTimer > p.cd - 12) {
                const e = players[1 - p.id];
                drawLightning(rc, p.x, p.y, e.x, e.y);
            }
        }
        drawCommentary(rc);
        drawHUDOnCanvas(rc);

        rc.restore();

    } else {
        // ── PORTRAIT: 540x960 layout ──
        rc.fillStyle = '#0a0a0f';
        rc.fillRect(0, 0, 540, 960);

        // Top section: P1 info (0-110)
        rc.fillStyle = 'rgba(20,20,40,0.9)';
        rc.fillRect(0, 0, 540, 110);
        rc.fillStyle = p1.color;
        rc.font = 'bold 22px Arial';
        rc.textAlign = 'center';
        rc.fillText(p1.name, 270, 35);
        rc.fillStyle = '#111';
        rc.fillRect(30, 50, 480, 25);
        const h1p = Math.max(0, p1.hp / p1.maxHp);
        rc.fillStyle = p1.color;
        rc.fillRect(32, 52, 476 * h1p, 21);
        rc.fillStyle = '#fff';
        rc.font = 'bold 14px Arial';
        rc.fillText(`${Math.max(0, Math.round(p1.hp))} / ${p1.maxHp}`, 270, 68);
        rc.fillStyle = '#ffd93d';
        rc.font = 'bold 16px Arial';
        rc.fillText(`Round ${currentRound}/${maxRounds} • ${score[0]}-${score[1]}`, 270, 100);

        // Middle: Arena (scaled)
        const arenaScale = 520 / 900;
        const arenaH = 500 * arenaScale;
        const arenaY = 120 + (520 - arenaH) / 2;
        rc.save();
        rc.translate(10, arenaY);
        rc.scale(arenaScale, arenaScale);

        drawArena(rc);
        drawObstacles(rc);
        for (const m of minions) m.draw(rc);
        for (const pr of projectiles) pr.draw(rc);
        for (const pt of particles) pt.draw(rc);
        for (const pu of powerUps) pu.draw(rc);
        drawPlayer(rc, p1);
        drawPlayer(rc, p2);
        for (const dn of damageNumbers) dn.draw(rc);
        for (const p of players) {
            if (p.alive && p.ability === 'lightning' && p.cdTimer > p.cd - 12) {
                const e = players[1 - p.id];
                drawLightning(rc, p.x, p.y, e.x, e.y);
            }
        }

        rc.restore();

        // Commentary in middle
        if (commentary.timer > 0) {
            const alpha = Math.min(1, commentary.timer / 20);
            rc.globalAlpha = alpha;
            rc.fillStyle = commentary.color;
            rc.strokeStyle = '#000';
            rc.lineWidth = 3;
            rc.font = `bold ${commentary.size}px Arial`;
            rc.textAlign = 'center';
            rc.strokeText(commentary.text, 270, 660);
            rc.fillText(commentary.text, 270, 660);
            if (commentary.subText) {
                rc.font = 'bold 12px Arial';
                rc.fillStyle = '#ddd';
                rc.strokeText(commentary.subText, 270, 685);
                rc.fillText(commentary.subText, 270, 685);
            }
            rc.globalAlpha = 1;
        }

        // Bottom section: P2 info (710-820)
        rc.fillStyle = 'rgba(20,20,40,0.9)';
        rc.fillRect(0, 710, 540, 110);
        rc.fillStyle = p2.color;
        rc.font = 'bold 22px Arial';
        rc.textAlign = 'center';
        rc.fillText(p2.name, 270, 745);
        rc.fillStyle = '#111';
        rc.fillRect(30, 760, 480, 25);
        const h2p = Math.max(0, p2.hp / p2.maxHp);
        rc.fillStyle = p2.color;
        rc.fillRect(32, 762, 476 * h2p, 21);
        rc.fillStyle = '#fff';
        rc.font = 'bold 14px Arial';
        rc.fillText(`${Math.max(0, Math.round(p2.hp))} / ${p2.maxHp}`, 270, 778);
        rc.fillStyle = '#aaa';
        rc.font = '12px Arial';
        rc.fillText(`⏱️ ${(time / 60).toFixed(0)}s`, 270, 810);

        // Stats area (830-960)
        rc.fillStyle = 'rgba(20,20,40,0.7)';
        rc.fillRect(0, 830, 540, 130);
        rc.font = '11px Arial';
        rc.fillStyle = '#888';
        rc.textAlign = 'left';
        rc.fillText(`${p1.name} DMG: ${p1.totalDmgDealt}`, 30, 855);
        rc.fillText(`${p1.name} Yetenek: ${p1.abilitiesUsed}`, 30, 875);
        rc.textAlign = 'right';
        rc.fillText(`DMG: ${p2.totalDmgDealt} ${p2.name}`, 510, 855);
        rc.fillText(`Yetenek: ${p2.abilitiesUsed} ${p2.name}`, 510, 875);

        // REC indicator
        rc.fillStyle = '#e74c3c';
        rc.beginPath();
        rc.arc(520, 845, 4, 0, Math.PI * 2);
        rc.fill();
        rc.fillStyle = '#fff';
        rc.font = 'bold 8px Arial';
        rc.textAlign = 'right';
        rc.fillText('REC', 514, 848);
    }
}


// ═══════════════════════════════════════════════════════
//  MAIN GAME LOOP (FIXED round-end logic)
// ═══════════════════════════════════════════════════════
function gameLoop() {
    if (paused || !gameRunning || matchOver) return;

    // ════════════════════════════════════════════════
    // ROUND END DELAY: Only visual updates, no game logic
    // ════════════════════════════════════════════════
    if (roundEndDelay > 0) {
        roundEndDelay--;

        // Update particles and damage numbers visually during delay
        for (let i = particles.length - 1; i >= 0; i--) {
            particles[i].update();
            if (particles[i].life <= 0) particles.splice(i, 1);
        }
        for (let i = damageNumbers.length - 1; i >= 0; i--) {
            damageNumbers[i].update();
            if (damageNumbers[i].life <= 0) damageNumbers.splice(i, 1);
        }
        updateScreenShake();

        if (slowMo.active) {
            slowMo.timer--;
            if (slowMo.timer <= 0) { slowMo.active = false; slowMo.factor = 1; }
        }

        renderFrame();

        // When delay finishes, decide: next round or match over
        if (roundEndDelay <= 0) {
            const neededWins = Math.ceil(maxRounds / 2);

            if (score[0] >= neededWins || score[1] >= neededWins || currentRound >= maxRounds) {
                // ── MATCH OVER ──
                matchOver = true;
                gameRunning = false;
                const finalWinner = score[0] >= score[1] ? 0 : 1;
                showWinner(finalWinner);

                // Victory fanfare
                playSound('bell', 523, 0.8, 0.5);
                setTimeout(() => playSound('bell', 659, 0.8, 0.5), 200);
                setTimeout(() => playSound('bell', 784, 1.0, 0.5), 400);
                return;
            } else {
                // ── NEXT ROUND ──
                currentRound++;
                resetRound();
            }
        }

        animId = requestAnimationFrame(gameLoop);
        return;
    }

    // ════════════════════════════════════════════════
    // NORMAL GAME LOGIC
    // ════════════════════════════════════════════════

    // Slow-mo decay
    if (slowMo.active) {
        slowMo.timer--;
        if (slowMo.timer <= 0) { slowMo.active = false; slowMo.factor = 1; }
    }

    const effectiveSpeed = arenaConfig.simSpeed * (slowMo.active ? slowMo.factor : 1);
    const steps = Math.max(1, Math.round(effectiveSpeed * 1.5));

    for (let s = 0; s < steps; s++) {
        // Don't continue processing if round just ended in this tick
        if (roundEnded) break;

        time++;

        // AI
        updateAI(players[0], players[1]);
        updateAI(players[1], players[0]);

        // Physics
        updatePhysics(players[0]);
        updatePhysics(players[1]);
        playerCollision(players[0], players[1]);

        // Projectiles
        for (const proj of projectiles) proj.update();
        checkProjectileHits();

        // Minions
        for (let i = minions.length - 1; i >= 0; i--) {
            minions[i].update(players[1 - minions[i].owner]);
            if (minions[i].life <= 0 || minions[i].hp <= 0) {
                spawnParticles(minions[i].x, minions[i].y, '#2ecc71', 5, 2, 15, 2, 'circle');
                minions.splice(i, 1);
            }
        }

        // Particles
        for (let i = particles.length - 1; i >= 0; i--) {
            particles[i].update();
            if (particles[i].life <= 0) particles.splice(i, 1);
        }

        // Damage numbers
        for (let i = damageNumbers.length - 1; i >= 0; i--) {
            damageNumbers[i].update();
            if (damageNumbers[i].life <= 0) damageNumbers.splice(i, 1);
        }

        // Cyberpunk Lasers & Meteor Showers
        if (arenaConfig.type === 'cyberpunk' && Math.random() < 0.001) {
            // Rare laser strike
            const targetX = Math.random() * canvas.width;
            showCommentary('ability', t('laserMsg'));
            playSound('zap', 400, 0.5, 0.5);
            projectiles.push(new Projectile(targetX, 0, 0, 10, -1, 'lightning', 25, 100)); // falling laser
        }
        
        // Meteor Shower (Sudden Death) after 45 seconds (2700 ticks)
        if (time > 2700 && Math.random() < 0.005) {
            if (time === 2701 || Math.random() < 0.0001) showCommentary('ability', t('meteorMsg'));
            const targetX = Math.random() * canvas.width;
            projectiles.push(new Projectile(targetX, -50, (Math.random()-0.5)*2, 6, -1, 'fireball', 40, 150));
            playSound('fire', 150, 0.4, 0.4);
        }

        // Camera Zoom logic (simulated by shaking or context scale, but let's just do an audience cheer for now)
        if (players[0].hp < players[0].maxHp * 0.3 && players[1].hp < players[1].maxHp * 0.3 && Math.random() < 0.002) {
            // Audience cheer
            playSound('summon', 150, 0.8, 0.6);
        }

        // Power-ups
        if (document.getElementById('powerUpsOn').value === '1') {
            for (let i = powerUps.length - 1; i >= 0; i--) {
                powerUps[i].update();
                if (powerUps[i].life <= 0) powerUps.splice(i, 1);
            }
            checkPowerUpPickup();
            if (time % 600 === 0 && powerUps.length < 3) {
                powerUps.push(new PowerUp());
            }
        }

        updateScreenShake();

        // ════════════════════════════════════════
        // DEATH CHECK (once per round only!)
        // ════════════════════════════════════════
        if (!roundEnded && (players[0].hp <= 0 || players[1].hp <= 0)) {
            roundEnded = true;  // ← LOCK: prevents re-entry

            const deadIdx = players[0].hp <= 0 ? 0 : 1;
            const winIdx = 1 - deadIdx;

            players[deadIdx].alive = false;
            players[deadIdx].hp = 0;
            score[winIdx]++;

            // Feedback
            showCommentary('kill', players[winIdx].name + ' ' + t('wins'));
            addLog(t('logWin', {name: players[winIdx].name, round: currentRound, s0: score[0], s1: score[1]}), 'kill');

            // Death sounds
            playSound('death', 200, 0.6, 0.4);
            setTimeout(() => playSound('boom', 60, 0.5, 0.5), 100);

            // Death particles
            const loser = players[deadIdx];
            spawnParticles(loser.x, loser.y, loser.color, 35, 5, 40, 4, 'circle');
            spawnParticles(loser.x, loser.y, '#ffd93d', 15, 4, 30, 3, 'spark');
            spawnParticles(loser.x, loser.y, '#fff', 4, 2, 25, 20, 'ring');
            spawnConfetti(canvas.width / 2, canvas.height / 2, players[winIdx].color);

            // Slow-mo on kill
            if (document.getElementById('slowMoOn').value === '1') {
                slowMo.active = true;
                slowMo.factor = 0.15;
                slowMo.timer = 80;
            }

            roundEndDelay = 150;  // ~2.5 seconds before next round
            break;  // Exit step loop immediately
        }
    }

    renderFrame();
    animId = requestAnimationFrame(gameLoop);
}

// ── Render a single frame ──
function renderFrame() {
    ctx.save();
    ctx.translate(screenShake.x, screenShake.y);

    drawArena(ctx);
    drawObstacles(ctx);

    for (const m of minions) m.draw(ctx);
    for (const proj of projectiles) proj.draw(ctx);
    for (const pt of particles) pt.draw(ctx);
    for (const pu of powerUps) pu.draw(ctx);

    drawPlayer(ctx, players[0]);
    drawPlayer(ctx, players[1]);

    for (const dn of damageNumbers) dn.draw(ctx);

    // Lightning bolt visual
    for (const p of players) {
        if (p.alive && p.ability === 'lightning' && p.cdTimer > p.cd - 12) {
            const enemy = players[1 - p.id];
            drawLightning(ctx, p.x, p.y, enemy.x, enemy.y);
        }
    }

    drawCommentary(ctx);
    drawHUDOnCanvas(ctx);

    // Slow-mo overlay
    if (slowMo.active) {
        ctx.fillStyle = 'rgba(255,255,255,0.06)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#ffd93d';
        ctx.font = 'bold 12px Arial';
        ctx.textAlign = 'left';
        ctx.globalAlpha = 0.7;
        ctx.fillText('◉ SLOW MOTION', 10, canvas.height - 8);
        ctx.globalAlpha = 1;
    }

    ctx.restore();

    updateHUD();

    // Record frame if recording or broadcasting portrait
    if (isRecording || document.body.classList.contains('broadcast-portrait')) {
        recordFrame();
    }
}


// ═══════════════════════════════════════════════════════
//  ROUND RESET
// ═══════════════════════════════════════════════════════
function resetRound() {
    roundEnded = false;
    projectiles = [];
    minions = [];
    powerUps = [];

    const configs = readConfig();

    for (let i = 0; i < 2; i++) {
        players[i].hp = configs[i].maxHp;
        players[i].maxHp = configs[i].maxHp;
        players[i].x = i === 0 ? 150 : 750;
        players[i].y = 250;
        players[i].vx = 0;
        players[i].vy = 0;
        players[i].cdTimer = 0;
        players[i].stunTimer = 0;
        players[i].poisonTimer = 0;
        players[i].rageActive = false;
        players[i].rageTimer = 0;
        players[i].comboCount = 0;
        players[i].shieldHp = 0;
        players[i].alive = true;
        players[i].hitFlash = 0;
        players[i].attackAnim = 0;
    }

    addLog(t('logRoundStart', {round: currentRound}), 'info');
    showCommentary('start');
    playSound('bell', 660, 0.4, 0.35);
}


// ═══════════════════════════════════════════════════════
//  CONTROLS
// ═══════════════════════════════════════════════════════
function startFight() {
    if (animId) cancelAnimationFrame(animId);

    // Unlock audio on user gesture
    ensureAudio();

    // Reset all state
    gameRunning = true;
    paused = false;
    matchOver = false;
    roundEnded = false;
    currentRound = 1;
    score = [0, 0];
    time = 0;
    roundEndDelay = 0;
    particles = [];
    projectiles = [];
    minions = [];
    damageNumbers = [];
    powerUps = [];
    combatLogEl.innerHTML = '';
    slowMo = { active: false, factor: 1, timer: 0 };
    commentary = { text: '', timer: 0, color: '#ffd93d', size: 28, subText: '', subTimer: 0 };

    // Create players
    players = readConfig();
    players[0].face = faceImages[0];
    players[0].team = playerTeams[0];
    players[1].face = faceImages[1];
    players[1].team = playerTeams[1];

    generateObstacles();

    document.getElementById('pauseBtn').textContent = '⏸️ DURDUR';

    // Start with intro or directly
    if (document.getElementById('introOn').value === '1') {
        introPhase = true;
        introTimer = 0;
        runIntro();
    } else {
        addLog(t('start'), 'info');
        showCommentary('start');
        playSound('bell', 660, 0.5, 0.4);
        gameLoop();
    }
}

function togglePause() {
    paused = !paused;
    document.getElementById('pauseBtn').textContent = paused ? '▶️ DEVAM' : '⏸️ DURDUR';

    if (!paused && gameRunning) {
        if (introPhase) runIntro();
        else gameLoop();
    }
}

function resetArena() {
    if (animId) cancelAnimationFrame(animId);
    gameRunning = false;
    paused = false;
    matchOver = false;
    roundEnded = false;
    autoMatchPhase = false;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    arenaConfig.type = document.getElementById('arenaType').value;
    drawArena(ctx);
    combatLogEl.innerHTML = '';
    document.getElementById('roundDisplay').textContent = t('ready');
    
    // Reset HUD
    document.getElementById('p1hpBar').style.width = '100%';
    document.getElementById('p2hpBar').style.width = '100%';
    document.getElementById('p1hpText').textContent = '-/-';
    document.getElementById('p2hpText').textContent = '-/-';
    document.getElementById('p1nameDisplay').textContent = '';
    document.getElementById('p2nameDisplay').textContent = '';

    if (isRecording) stopRecording();
}

function randomize() {
    const classes = ['wizard', 'paladin', 'assassin', 'berserker', 'necro', 'monk'];
    applyPreset(1, classes[Math.floor(Math.random() * classes.length)]);
    applyPreset(2, classes[Math.floor(Math.random() * classes.length)]);

    const randColor = () => '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
    document.getElementById('p1color').value = randColor();
    document.getElementById('p2color').value = randColor();

    const arenas = ['stone', 'lava', 'ice', 'forest', 'void', 'colosseum'];
    document.getElementById('arenaType').value = arenas[Math.floor(Math.random() * arenas.length)];

    // Random team assignment (50% chance)
    if (Math.random() > 0.5) {
        const teamKeys = Object.keys(footballTeams);
        applyTeam(1, teamKeys[Math.floor(Math.random() * teamKeys.length)]);
        applyTeam(2, teamKeys[Math.floor(Math.random() * teamKeys.length)]);
    }

    // Slight stat randomization
    ['p1', 'p2'].forEach(pf => {
        const hpEl = document.getElementById(pf + 'hp');
        hpEl.value = +hpEl.value + Math.round((Math.random() - 0.5) * 60);

        const spdEl = document.getElementById(pf + 'speed');
        spdEl.value = Math.max(1, Math.min(10, +spdEl.value + Math.round((Math.random() - 0.5) * 2)));

        const dmgEl = document.getElementById(pf + 'dmg');
        dmgEl.value = +dmgEl.value + Math.round((Math.random() - 0.5) * 10);

        const abilities = ['lightning', 'fireball', 'ice', 'hammer', 'dash', 'rage', 'summon', 'combo', 'shockwave', 'poison'];
        document.getElementById(pf + 'ability').value = abilities[Math.floor(Math.random() * abilities.length)];
    });

    syncAllRanges();
}

function showWinner(winnerIdx) {
    const overlay = document.getElementById('winnerOverlay');
    overlay.style.display = 'flex';

    const winText = document.getElementById('winnerText');
    winText.textContent = `🏆 ${players[winnerIdx].name} KAZANDI! 🏆`;
    winText.style.color = players[winnerIdx].color;

    const scoreText = document.getElementById('winnerScore');
    scoreText.innerHTML = `Final Skor: ${score[0]} - ${score[1]}<br>
        <small style="color:#aaa">
        ${players[0].name} DMG: ${players[0].totalDmgDealt} | Yetenek: ${players[0].abilitiesUsed}<br>
        ${players[1].name} DMG: ${players[1].totalDmgDealt} | Yetenek: ${players[1].abilitiesUsed}
        </small>`;

    if (isRecording) {
        setTimeout(() => stopRecording(), 1500);
    }
    
    if (autoMatchEnabled) {
        setTimeout(startVotePhase, 3000);
    }
}

function closeOverlay() {
    document.getElementById('winnerOverlay').style.display = 'none';
}


// ═══════════════════════════════════════════════════════
//  INITIALIZATION
// ═══════════════════════════════════════════════════════
arenaConfig = {
    type: 'stone',
    gravity: 0,
    friction: 0.97,
    obstacleCount: 4,
    simSpeed: 0.7,
    aiLevel: 2
};

drawArena(ctx);

// ═══════════════════════════════════════════════════════
//  LIVE STREAM INTEGRATION (WebSocket & Widgets)
// ═══════════════════════════════════════════════════════

let liveWS = null;

function connectLocalWS() {
    const port = document.getElementById('wsPortInput').value || '8080';
    const statusEl = document.getElementById('wsStatus');
    
    if (liveWS) {
        liveWS.close();
    }

    try {
        statusEl.textContent = 'Bağlanıyor...';
        statusEl.style.color = '#f39c12';
        liveWS = new WebSocket(`ws://127.0.0.1:${port}/`);
        
        liveWS.onopen = () => {
            statusEl.textContent = 'Bağlandı';
            statusEl.style.color = '#2ecc71';
            logStreamChat('Sistem', `Port ${port} üzerinden WebSocket'e bağlanıldı.`, false);
        };
        
        liveWS.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                if (data.event === 'ChatMessage' || data.type === 'message' || data.event?.type === 'message') {
                    const msg = data.message || data.data?.message || '';
                    const user = data.username || data.user || data.data?.sender || 'İzleyici';
                    handleChatMessage(msg, user, false);
                } else if (data.event === 'Cheer' || data.event === 'Donation' || data.type === 'superchat') {
                    const msg = data.message || data.data?.message || '';
                    const user = data.username || data.user || data.data?.sender || 'Destekçi';
                    handleChatMessage(msg, user, true);
                }
            } catch (e) {
                // Ignore parsing errors
            }
        };
        
        liveWS.onclose = () => {
            statusEl.textContent = 'Bağlantı Koptu';
            statusEl.style.color = '#ff4757';
        };
        
        liveWS.onerror = () => {
            statusEl.textContent = 'Hata';
            statusEl.style.color = '#ff4757';
        };
    } catch (err) {
        statusEl.textContent = 'Hata';
        statusEl.style.color = '#ff4757';
    }
}

// StreamElements Custom Widget Event Listener
window.addEventListener('onEventReceived', function (obj) {
    if (!obj.detail.event) return;
    const ev = obj.detail.listener;
    const event = obj.detail.event;

    if (ev === 'message') {
        handleChatMessage(event.data.text, event.data.displayName, false);
    } else if (ev === 'tip-latest' || ev === 'cheer-latest' || ev === 'superchat-latest') {
        handleChatMessage(event.message || '', event.name || 'Destekçi', true);
    }
});

let autoMatchEnabled = false;
let autoMatchPhase = false;
let matchVotes = {};
let voteTimer = 0;
let voteIntervalId = null;

window.toggleAutoMatch = function() {
    autoMatchEnabled = document.getElementById('autoMatchCheck')?.checked;
    if (!autoMatchEnabled && autoMatchPhase) {
        clearInterval(voteIntervalId);
        autoMatchPhase = false;
        document.getElementById('roundDisplay').textContent = t('ready');
    }
};

function handleChatMessage(msg, username, isSuperchat) {
    if (!msg) return;
    const text = msg.toLowerCase();
    
    if (autoMatchEnabled && autoMatchPhase) {
        // Vote processing
        const teamKeys = Object.keys(footballTeams);
        for (const key of teamKeys) {
            const team = footballTeams[key];
            if (text.includes(team.short.toLowerCase()) || text.includes(team.name.toLowerCase())) {
                matchVotes[key] = (matchVotes[key] || 0) + (isSuperchat ? 5 : 1); // Superchat gives 5 votes
            }
        }
        return; // Don't apply buffs during voting phase
    }

    players.forEach(p => {
        let shortMatch = false;
        let longMatch = false;
        let matchName = p.name;
        
        if (p.team && footballTeams[p.team]) {
            const teamObj = footballTeams[p.team];
            shortMatch = text.includes(teamObj.short.toLowerCase());
            longMatch = text.includes(teamObj.name.toLowerCase());
            matchName = teamObj.name;
        } else {
            longMatch = text.includes(p.name.toLowerCase());
        }
        
        if (shortMatch || longMatch) {
            if (isSuperchat) {
                p.cdTimer = 0;
                logStreamChat(username, `💸 [SUPERCHAT] ${matchName} ${t('superchatPower')} (${msg})`, true);
                showCommentary('powerup', t('logSuperchat', {name: username.toUpperCase()}));
            } else {
                p.chatDamageMultiplier = 1.5;
                p.chatBuffTimer = 180;
                // Healing: +5% of max HP
                p.hp = Math.min(p.maxHp, p.hp + (p.maxHp * 0.05));
                if (gameRunning) updateHUD();
                
                logStreamChat(username, `💬 ${matchName} ${t('supportedTeam')} (${msg})`, false);
            }
        }
    });
}

function logStreamChat(username, text, isSuperchat) {
    const logBox = document.getElementById('streamChatLog');
    if (!logBox) return;
    
    const div = document.createElement('div');
    div.style.marginBottom = '4px';
    div.style.padding = '3px';
    div.style.borderRadius = '3px';
    if (isSuperchat) {
        div.style.backgroundColor = 'rgba(255, 159, 67, 0.3)';
        div.style.borderLeft = '3px solid #ff9f43';
    } else {
        div.style.borderLeft = '3px solid #00d2d3';
    }
    
    div.innerHTML = `<strong>${username}:</strong> ${text}`;
    logBox.appendChild(div);
    logBox.scrollTop = logBox.scrollHeight;
}

// Simulation functions triggered by UI Buttons
window.simulateChatBuff = function(playerNum) {
    const p = players[playerNum - 1];
    if (!p) return;
    let tName = p.team ? footballTeams[p.team].name : p.name;
    handleChatMessage(`${tName}!!!`, t('simUser') + `_${Math.floor(Math.random()*100)}`, false);
}

window.simulateSuperchat = function(playerNum) {
    const p = players[playerNum - 1];
    if (!p) return;
    let tName = p.team ? footballTeams[p.team].name : p.name;
    handleChatMessage(`${tName}`, t('simVip') + `_${Math.floor(Math.random()*100)}`, true);
}

function startVotePhase() {
    closeOverlay();
    autoMatchPhase = true;
    matchVotes = {};
    voteTimer = 15; // 15 seconds voting
    
    // Clear arena for voting display
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawArena(ctx);
    
    document.getElementById('roundDisplay').textContent = t('voteStart');
    
    if (voteIntervalId) clearInterval(voteIntervalId);
    
    voteIntervalId = setInterval(() => {
        voteTimer--;
        
        // Draw voting status on canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawArena(ctx);
        ctx.fillStyle = 'rgba(0,0,0,0.7)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 36px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(t('voteStart'), canvas.width / 2, 100);
        
        ctx.font = '24px Arial';
        ctx.fillStyle = '#f39c12';
        ctx.fillText(t('voteTimer', {time: voteTimer}), canvas.width / 2, 150);
        
        // Draw top 5 votes
        const sortedVotes = Object.entries(matchVotes).sort((a,b) => b[1] - a[1]).slice(0, 5);
        ctx.font = '20px Arial';
        ctx.fillStyle = '#fff';
        let startY = 220;
        for (let i = 0; i < sortedVotes.length; i++) {
            const team = footballTeams[sortedVotes[i][0]];
            ctx.fillText(`${i+1}. ${team.name} - ${sortedVotes[i][1]} oy`, canvas.width / 2, startY + (i * 30));
        }
        
        if (voteTimer <= 0) {
            clearInterval(voteIntervalId);
            endVotePhase();
        }
    }, 1000);
}

function endVotePhase() {
    autoMatchPhase = false;
    document.getElementById('roundDisplay').textContent = t('ready');
    
    const sortedVotes = Object.entries(matchVotes).sort((a,b) => b[1] - a[1]);
    let team1 = '';
    let team2 = '';
    
    const teamKeys = Object.keys(footballTeams);
    
    if (sortedVotes.length >= 2) {
        team1 = sortedVotes[0][0];
        team2 = sortedVotes[1][0];
    } else if (sortedVotes.length === 1) {
        team1 = sortedVotes[0][0];
        team2 = teamKeys[Math.floor(Math.random() * teamKeys.length)];
        if (team1 === team2) team2 = teamKeys[Math.floor(Math.random() * teamKeys.length)];
    } else {
        // Fallback random
        team1 = teamKeys[Math.floor(Math.random() * teamKeys.length)];
        team2 = teamKeys[Math.floor(Math.random() * teamKeys.length)];
    }
    
    logStreamChat('Sistem', t('autoMatchStart', {t1: footballTeams[team1].name, t2: footballTeams[team2].name}), false);
    
    // Apply presets and teams
    const classes = ['wizard', 'paladin', 'assassin', 'berserker', 'necro', 'monk'];
    applyPreset(1, classes[Math.floor(Math.random() * classes.length)]);
    applyPreset(2, classes[Math.floor(Math.random() * classes.length)]);
    
    applyTeam(1, team1);
    applyTeam(2, team2);
    
    // Small delay to let user see selection, then start fight
    setTimeout(() => {
        startFight();
    }, 2000);
}

// ═══════════════════════════════════════════════════════════════════════════════
//  FOOTBALL API ENTEGRASYONU - Otomatik Mac Sistemi
// ═══════════════════════════════════════════════════════════════════════

// Football API durumları
const FOOTBALL_STATES = {
    IDLE: 'IDLE',           // Hazır
    LOADING: 'LOADING',       // API çağrısı yapılıyor
    MATCH_FOUND: 'MATCH_FOUND', // Maç bulundu
    INTRO: 'INTRO',         // Giriş animasyonu
    ROUND_1: 'ROUND_1',     // 1. Round
    INTERMISSION: 'INTERMISSION', // Ara
    ROUND_2: 'ROUND_2',     // 2. Round
    INTERMISSION_2: 'INTERMISSION_2',
    ROUND_3: 'ROUND_3',     // 3. Round
    MATCH_END: 'MATCH_END',   // Maç sonu
    WAITING_NEXT: 'WAITING_NEXT' // Yeni maç bekle
};

let footballState = FOOTBALL_STATES.IDLE;
let autoModeEnabled = false;
let currentFixtures = [];
let currentFixtureIndex = 0;

// Takım ID'den oyun ayarlarına çevir
function getTeamConfig(teamId) {
    // Team mapping varsa kullan
    if (typeof CONFIG !== 'undefined' && CONFIG.TEAM_MAPPING) {
        const mapped = CONFIG.TEAM_MAPPING[teamId.toString()];
        if (mapped) {
            return {
                name: mapped.name,
                preset: mapped.preset,
                color: mapped.color,
                arena: mapped.arena
            };
        }
    }
    
    // Default fallback
    const presets = ['wizard', 'paladin', 'assassin', 'berserker', 'necro', 'monk'];
    const arenas = ['stone', 'forest', 'ice', 'void', 'colosseum', 'cyberpunk'];
    const colors = ['#9b59b6', '#3498db', '#2ecc71', '#e74c3c', '#f39c12', '#1abc9c'];
    
    // Takım ID'ye göre deterministik seçim
    const hash = String(teamId).split('').reduce((a, b) => a + parseInt(b), 0);
    
    return {
        name: `Takim ${teamId}`,
        preset: presets[hash % presets.length],
        color: colors[hash % colors.length],
        arena: arenas[hash % arenas.length]
    };
}

// Football API'den maçları çek
async function fetchTodayFixtures() {
    if (typeof CONFIG === 'undefined' || !CONFIG.isApiConfigured()) {
        console.log('Football API: CONFIG bulunamadı veya API key yok');
        return [];
    }
    
    try {
        const date = CONFIG.getTodayDate();
        const leagueIds = CONFIG.getLeagueIds();
        
        const response = await fetch(
            `https://free-api-live-football-data.p.rapidapi.com/football-get-matches-by-date-and-league?date=${date.replace(/-/g,'')}`,
            {
                headers: {
                    'x-rapidapi-host': CONFIG.RAPIDAPI_HOST,
                    'x-rapidapi-key': CONFIG.RAPIDAPI_KEY
                }
            }
        );
        
        const data = await response.json();
        
        if (data.errors && data.errors.length > 0) {
            console.log('Football API hata:', data.errors);
            return [];
        }
        
        return data.response || [];
        
    } catch (e) {
        console.log('Football API ağ hatası:', e);
        return [];
    }
}

// API-Football'dan maç bul ve ayarla
async function setupFixtureFromAPI(fixture) {
    if (!fixture) return false;
    
    const homeTeam = fixture.teams.home;
    const awayTeam = fixture.teams.away;
    
    if (!homeTeam || !awayTeam) return false;
    
    const homeConfig = getTeamConfig(homeTeam.id);
    const awayConfig = getTeamConfig(awayTeam.id);
    
    // Takımları ayarla
    applyPreset(1, homeConfig.preset);
    applyPreset(2, awayConfig.preset);
    
    // İsim ve renk
    document.getElementById('p1name').value = homeTeam.name;
    document.getElementById('p2name').value = awayTeam.name;
    document.getElementById('p1color').value = homeConfig.color;
    document.getElementById('p2color').value = awayConfig.color;
    
    // Arena tipi
    document.getElementById('arenaType').value = homeConfig.arena;
    
    console.log(`Maç ayarlandı: ${homeTeam.name} vs ${awayTeam.name}`);
    
    return true;
}

// Otomatik maç döngüsü başlat
async function startAutoMode() {
    if (typeof CONFIG !== 'undefined' && !CONFIG.isApiConfigured()) {
        alert('Lütfen önce config.js dosyasına RAPIDAPI_KEY girin!');
        return;
    }
    
    autoModeEnabled = true;
    footballState = FOOTBALL_STATES.LOADING;
    
    console.log('Otomatik mod başladı');
    
    await runAutoLoop();
}

// Otomatik döngü
async function runAutoLoop() {
    while (autoModeEnabled) {
        // Maçları çek
        footballState = FOOTBALL_STATES.LOADING;
        currentFixtures = await fetchTodayFixtures();
        
        if (currentFixtures.length === 0) {
            console.log('Bugün maç yok, bekleniyor...');
            footballState = FOOTBALL_STATES.WAITING_NEXT;
            
            // 30 saniye bekle ve tekrar dene
            await new Promise(r => setTimeout(r, CONFIG.API_RETRY_INTERVAL * 1000));
            continue;
        }
        
        // Her maçı sırayla oyna
        for (let i = 0; i < currentFixtures.length && autoModeEnabled; i++) {
            const fixture = currentFixtures[i];
            
            // Maçı ayarla
            footballState = FOOTBALL_STATES.MATCH_FOUND;
            const success = await setupFixtureFromAPI(fixture);
            
            if (!success) continue;
            
            console.log(`Maç başlıyor: ${fixture.teams.home.name} vs ${fixture.teams.away.name}`);
            
            // 3 Round oyna
            for (let round = 1; round <= 3 && autoModeEnabled; round++) {
                footballState = 'ROUND_' + round;
                
                startFight();
                
                // Round bitene bekle (~60 saniye + bekleme)
                await new Promise(r => setTimeout(r, 65000));
                
                // Round arası bekleme
                if (round < 3 && autoModeEnabled) {
                    footballState = FOOTBALL_STATES.INTERMISSION;
                    await new Promise(r => setTimeout(r, CONFIG.INTERMISSION_TIME * 1000));
                }
            }
            
            // Maç sonu bekleme
            footballState = FOOTBALL_STATES.MATCH_END;
            await new Promise(r => setTimeout(r, CONFIG.MATCH_END_TIME * 1000));
        }
        
        // Maçlar bitince yenile
        if (autoModeEnabled) {
            footballState = FOOTBALL_STATES.WAITING_NEXT;
            await new Promise(r => setTimeout(r, CONFIG.API_RETRY_INTERVAL * 1000));
        }
    }
    
    footballState = FOOTBALL_STATES.IDLE;
    console.log('Otomatik mod durduruldu');
}

// Otomatik mod durdur
function stopAutoMode() {
    autoModeEnabled = false;
    console.log('Otomatik mod durduruluyo...');
}

// Arena fonksiyonlarını dışarıya aç
window.setupFixtureFromAPI = setupFixtureFromAPI;
window.startAutoMode = startAutoMode;
window.stopAutoMode = stopAutoMode;
window.getTeamConfig = getTeamConfig;
window.fetchTodayFixtures = fetchTodayFixtures;

// Cross-origin file:// iframe mesaj dinleyicisi (auto-arena.html den gelen mesajlar)
window.addEventListener('message', (event) => {
    try {
        const data = event.data;
        if (!data || !data.type) return;
        
        if (data.type === 'setupMatch') {
            if (data.p1preset) applyPreset(1, data.p1preset);
            if (data.p2preset) applyPreset(2, data.p2preset);
            
            const ids = ['p1color', 'p2color', 'p1name', 'p2name', 'arenaType'];
            ids.forEach(id => {
                if (data[id]) {
                    const el = document.getElementById(id);
                    if (el) el.value = data[id];
                }
            });
        } else if (data.type === 'startFight') {
            if (typeof startFight === 'function') startFight();
        } else if (data.type === 'toggleBroadcast') {
            if (data.enabled) {
                document.body.classList.add('broadcast-mode');
                if (data.mode === 'portrait') {
                    document.body.classList.add('broadcast-portrait');
                    if (!isRecording) {
                        recordMode = 'portrait';
                        recCanvas.width = 540;
                        recCanvas.height = 960;
                    }
                } else {
                    document.body.classList.remove('broadcast-portrait');
                }
            } else {
                document.body.classList.remove('broadcast-mode');
                document.body.classList.remove('broadcast-portrait');
            }
        }
    } catch (e) {
        console.error('Mesaj işleme hatası:', e);
    }
});
