const CONFIG = {
    // ═══════════════════════════════════════════════════════════
    //  API KEY'LER - SONRA DOLDURULACAK
    // ═══════════════════════════════════════════════════════════
    
    RAPIDAPI_KEY: '227d0ed04dmsha13ccedea6a150ep156e58jsn8dd6d6f0d487',
    RAPIDAPI_HOST: 'free-api-live-football-data.p.rapidapi.com',
    
    // ═══════════════════════════════════════════════════════════
    //  OBS WEBSOCKET - SONRA DOLDURULACAK
    // ═══════════════════════════════════════════════════════════
    
    OBS_PASSWORD: 'obsobs',
    OBS_HOST: 'localhost',
    OBS_PORT: 4455,
    OBS_SCENE_NAME: 'Arena',
    
    // ═══════════════════════════════════════════════════════════
    //  YOUTUBE STREAM KEY - SONRA DOLDURULACAK
    // ═══════════════════════════════════════════════════════════
    
    YOUTUBE_STREAM_KEY: 'gby3-afcs-edy6-7e13-7yat',
    
    // ═══════════════════════════════════════════════════════════
    //  LIG IDLERI (Sabit)
    // ═══════════════════════════════════════════════════════════
    
    LEAGUES: [
        { id: 39, name: 'Premier League', country: 'England' },
        { id: 140, name: 'La Liga', country: 'Spain' },
        { id: 203, name: 'Süper Lig', country: 'Turkey' },
        { id: 2, name: 'Champions League', country: 'Europe' }
    ],
    
    // ═══════════════════════════════════════════════════════════
    //  ZAMANLAMA (saniye)
    // ═══════════════════════════════════════════════════════════
    
    INTERMISSION_TIME: 5,
    MATCH_END_TIME: 10,
    API_RETRY_INTERVAL: 30,
    INTRO_TIME: 3,
    
    // ═══════════════════════════════════════════════════════════
    //  OTOMATIK MOD AYARLARI
    // ═══════════════════════════════════════════════════════════
    
    MAX_ROUNDS: 3,
    AUTO_MODE: false,
    
    // ═══════════════════════════════════════════════════════════
    //  TAKIM MAPPING - Takim ID -> Oyun Ayarlari
    // ═══════════════════════════════════════════════════════════
    
    TEAM_MAPPING: {
        // Premier League (39)
        '33': { name: 'Arsenal', preset: 'assassin', color: '#EF0107', arena: 'stone' },
        '34': { name: 'Aston Villa', preset: 'wizard', color: '#670E36', arena: 'stone' },
        '35': { name: 'Bournemouth', preset: 'berserker', color: '#DA291C', arena: 'forest' },
        '36': { name: 'Brentford', preset: 'wizard', color: '#E30617', arena: 'stone' },
        '37': { name: 'Brighton', preset: 'wizard', color: '#0057B8', arena: 'ice' },
        '38': { name: 'Burnley', preset: 'berserker', color: '#6C1B45', arena: 'forest' },
        '39': { name: 'Chelsea', preset: 'monk', color: '#034694', arena: 'cyberpunk' },
        '40': { name: 'Crystal Palace', preset: 'assassin', color: '#1B458F', arena: 'stone' },
        '41': { name: 'Everton', preset: 'paladin', color: '#003399', arena: 'colosseum' },
        '42': { name: 'Fulham', preset: 'wizard', color: '#CC0000', arena: 'stone' },
        '43': { name: 'Liverpool', preset: 'berserker', color: '#C8102E', arena: 'forest' },
        '44': { name: 'Luton', preset: 'wizard', color: '#FDB913', arena: 'stone' },
        '45': { name: 'Man City', preset: 'wizard', color: '#6CABDD', arena: 'ice' },
        '46': { name: 'Man United', preset: 'berserker', color: '#DA291C', arena: 'forest' },
        '47': { name: 'Newcastle', preset: 'assassin', color: '#241F20', arena: 'stone' },
        '49': { name: 'Southampton', preset: 'assassin', color: '#DA291A', arena: 'stone' },
        '51': { name: 'West Ham', preset: 'paladin', color: '#7A263A', arena: 'colosseum' },
        '52': { name: 'Wolves', preset: 'wizard', color: '#FDB913', arena: 'stone' },
        
        // La Liga (140)
        '157': { name: 'Athletic Bilbao', preset: 'paladin', color: '#E20513', arena: 'colosseum' },
        '158': { name: 'Barcelona', preset: 'assassin', color: '#A50044', arena: 'cyberpunk' },
        '159': { name: 'Getafe', preset: 'berserker', color: '#094D8F', arena: 'stone' },
        '160': { name: 'Girona', preset: 'wizard', color: '#E40521', arena: 'stone' },
        '164': { name: 'Osasuna', preset: 'berserker', color: '#D70121', arena: 'forest' },
        '165': { name: 'Real Betis', preset: 'wizard', color: '#009B3A', arena: 'stone' },
        '166': { name: 'Real Madrid', preset: 'wizard', color: '#FEBE10', arena: 'stone' },
        '167': { name: 'Real Sociedad', preset: 'wizard', color: '#004D98', arena: 'stone' },
        '168': { name: 'Sevilla', preset: 'assassin', color: '#D6001C', arena: 'stone' },
        '170': { name: 'Villarreal', preset: 'wizard', color: '#FFDE00', arena: 'stone' },
        
        // Süper Lig (203)
        '83': { name: 'Besiktas', preset: 'berserker', color: '#000000', arena: 'stone' },
        '85': { name: 'Fenerbahce', preset: 'paladin', color: '#FEBE10', arena: 'colosseum' },
        '86': { name: 'Galatasaray', preset: 'paladin', color: '#FFD700', arena: 'colosseum' },
        '99': { name: 'Trabzonspor', preset: 'wizard', color: '#6A0032', arena: 'forest' },
        
        // Champions League (2)
        '190': { name: 'Arsenal', preset: 'assassin', color: '#EF0107', arena: 'stone' },
        '195': { name: 'Atletico Madrid', preset: 'berserker', color: '#CB3524', arena: 'forest' },
        '196': { name: 'Barcelona', preset: 'assassin', color: '#A50044', arena: 'cyberpunk' },
        '197': { name: 'Bayern', preset: 'assassin', color: '#DC052D', arena: 'void' },
        '200': { name: 'Chelsea', preset: 'monk', color: '#034694', arena: 'cyberpunk' },
        '204': { name: 'Dortmund', preset: 'assassin', color: '#FDE100', arena: 'void' },
        '207': { name: 'Inter', preset: 'paladin', color: '#009DE0', arena: 'colosseum' },
        '208': { name: 'Juventus', preset: 'paladin', color: '#000000', arena: 'colosseum' },
        '209': { name: 'Liverpool', preset: 'berserker', color: '#C8102E', arena: 'forest' },
        '210': { name: 'Man City', preset: 'wizard', color: '#6CABDD', arena: 'ice' },
        '211': { name: 'Man United', preset: 'berserker', color: '#DA291C', arena: 'forest' },
        '214': { name: 'PSG', preset: 'monk', color: '#004170', arena: 'void' },
        '216': { name: 'Real Madrid', preset: 'wizard', color: '#FEBE10', arena: 'stone' },
        '218': { name: 'Tottenham', preset: 'assassin', color: '#132257', arena: 'void' }
    },
    
    // ═══════════════════════════════════════════════════════════
    //  YARDIMCI FONKSIYONLAR
    // ═══════════════════════════════════════════════════════════
    
    getApiKey: function() {
        return this.RAPIDAPI_KEY;
    },
    
    isApiConfigured: function() {
        return this.RAPIDAPI_KEY && this.RAPIDAPI_KEY.length > 0;
    },
    
    isObsConfigured: function() {
        return this.OBS_PASSWORD && this.OBS_PASSWORD.length > 0;
    },
    
    getTeamById: function(teamId) {
        if (!teamId) return null;
        return this.TEAM_MAPPING[teamId.toString()] || null;
    },
    
    getTeamByName: function(teamName) {
        if (!teamName) return null;
        const nameLower = teamName.toLowerCase();
        
        // Önce tam eşleşme dene
        for (const [id, team] of Object.entries(this.TEAM_MAPPING)) {
            if (team.name.toLowerCase() === nameLower) {
                return team;
            }
        }
        
        // Kısmi eşleşme
        for (const [id, team] of Object.entries(this.TEAM_MAPPING)) {
            if (team.name.toLowerCase().includes(nameLower) || nameLower.includes(team.name.toLowerCase())) {
                return team;
            }
        }
        
        // Alternatif isimler
        const altNames = {
            'crystal palace': {name: 'Crystal Palace', preset: 'assassin', color: '#1B458F', arena: 'stone'},
            'west ham': {name: 'West Ham', preset: 'paladin', color: '#7A263A', arena: 'colosseum'},
            'athletic club': {name: 'Athletic Bilbao', preset: 'paladin', color: '#E20513', arena: 'colosseum'},
            'athletic': {name: 'Athletic Bilbao', preset: 'paladin', color: '#E20513', arena: 'colosseum'},
            'osasuna': {name: 'Osasuna', preset: 'berserker', color: '#D70121', arena: 'forest'},
            'mallorca': {name: 'Mallorca', preset: 'wizard', color: '#FF0000', arena: 'forest'},
            'valencia': {name: 'Valencia', preset: 'wizard', color: '#FF0000', arena: 'stone'},
            'manchester city': {name: 'Man City', preset: 'wizard', color: '#6CABDD', arena: 'ice'},
            'man city': {name: 'Man City', preset: 'wizard', color: '#6CABDD', arena: 'ice'},
            'liverpool': {name: 'Liverpool', preset: 'berserker', color: '#C8102E', arena: 'forest'},
            'arsenal': {name: 'Arsenal', preset: 'assassin', color: '#EF0107', arena: 'stone'},
            'chelsea': {name: 'Chelsea', preset: 'monk', color: '#034694', arena: 'cyberpunk'},
            'manchester united': {name: 'Man United', preset: 'berserker', color: '#DA291C', arena: 'forest'},
            'man united': {name: 'Man United', preset: 'berserker', color: '#DA291C', arena: 'forest'},
            'tottenham': {name: 'Tottenham', preset: 'assassin', color: '#132257', arena: 'void'},
            'real madrid': {name: 'Real Madrid', preset: 'wizard', color: '#FEBE10', arena: 'stone'},
            'barcelona': {name: 'Barcelona', preset: 'assassin', color: '#A50044', arena: 'cyberpunk'},
            'bayern': {name: 'Bayern', preset: 'assassin', color: '#DC052D', arena: 'void'},
            'psg': {name: 'PSG', preset: 'monk', color: '#004170', arena: 'void'},
            'inter': {name: 'Inter', preset: 'paladin', color: '#009DE0', arena: 'colosseum'},
            'juventus': {name: 'Juventus', preset: 'paladin', color: '#000000', arena: 'colosseum'},
            'milan': {name: 'AC Milan', preset: 'monk', color: '#FB090B', arena: 'void'},
            'dortmund': {name: 'Dortmund', preset: 'assassin', color: '#FDE100', arena: 'void'},
        };
        
        for (const [key, team] of Object.entries(altNames)) {
            if (nameLower.includes(key) || key.includes(nameLower)) {
                return team;
            }
        }
        
        return null;
    },
    
    getTodayDate: function() {
        return new Date().toISOString().split('T')[0];
    },
    
    getTodayDateFormatted: function() {
        // Format: YYYYMMDD for this API
        const d = new Date();
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return year + month + day;
    },
    
    getLeagueIds: function() {
        return this.LEAGUES.map(l => l.id).join(',');
    }
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
}